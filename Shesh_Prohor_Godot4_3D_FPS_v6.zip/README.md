# শেষ প্রহর - Godot 4.3 Real 3D Assets Edition (Version 6.0)

## ভার্সন ৬.০-তে যা যা যুক্ত হয়েছে
- **Poly Haven ফটোস্ক্যানড PBR টেক্সচার ও আসল `.hdr` আকাশ:** বিল্ডের সময় অটোমেটিক আসল ক্যামেরায় তোলা PBR টেক্সচার (Albedo, Normal, Roughness, AO) এবং আসল `.hdr` স্কাইবক্স ডাউনলোড হয়ে প্রজেক্টে যুক্ত হবে।
- **ইউনিভার্সাল `.glb` ৩ডি মডেল লোডার (`AssetLoader.gd`):** বক্স বাদ দিয়ে আসল `.glb` ৩ডি মডেল অটো-স্কেলিং ও অটো-কলিশনসহ লোড হবে।
- **ড্রপ-ইন কাস্টম ৩ডি মডেল সাপোর্ট:** আপনি Sketchfab, Mixamo বা Poly Haven থেকে যেকোনো `.glb` ডাউনলোড করে নিচের নামে GitHub রিপোজিটরিতে আপলোড করলেই কোনো কোড না বদলে গেমে বসে যাবে:
  - `fps_arms.glb` (আসল মানুষের হাত)
  - `ak47.glb`, `sniper.glb`, `shotgun.glb`, `pistol.glb` (৪টি আসল অস্ত্র)
  - `soldier.glb` / `ally.glb` / `enemy.glb` (রিগড ৩ডি মানুষ)
  - `building.glb`, `tree.glb`, `jeep.glb`, `crate.glb`, `barrel.glb` (পরিবেশের আসল ৩ডি অবজেক্ট)
