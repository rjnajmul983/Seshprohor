extends CharacterBody3D
class_name SoldierUnit

var hp: float = 100.0
var max_hp: float = 100.0
var move_speed: float = 3.2
var is_ally: bool = false
var last_shot_time: float = 0.0
var strafe_dir: float = 1.0
var strafe_timer: float = 0.0
var anim_player: AnimationPlayer = null
var soldier_visual: Node3D = null
var muzzle_flash: OmniLight3D = null
var current_anim: String = ""
var is_dead: bool = false

func setup(p_hp: float, p_speed: float, p_ally: bool) -> void:
	hp = p_hp; max_hp = p_hp; move_speed = p_speed; is_ally = p_ally
	strafe_dir = 1.0 if randf() > 0.5 else -1.0
	strafe_timer = randf_range(1.2, 2.8)

	var col = CollisionShape3D.new()
	var cap = CapsuleShape3D.new(); cap.radius = 0.42; cap.height = 1.78
	col.shape = cap; col.position.y = 0.9
	add_child(col)

	muzzle_flash = OmniLight3D.new()
	muzzle_flash.light_color = Color(1.0, 0.72, 0.22); muzzle_flash.light_energy = 0.0
	muzzle_flash.omni_range = 7.0; muzzle_flash.position = Vector3(0.2, 1.35, -0.55)
	add_child(muzzle_flash)

	var candidates = ["ally", "soldier", "Soldier"] if p_ally else ["enemy", "soldier", "Soldier"]
	var loaded_path = ""
	for cname in candidates:
		var p = "res://assets/models/%s.glb" % cname
		if ResourceLoader.exists(p):
			loaded_path = p; break

	if loaded_path != "":
		var scene_res = load(loaded_path)
		if scene_res is PackedScene:
			soldier_visual = scene_res.instantiate()
			soldier_visual.rotation.y = PI
			add_child(soldier_visual)
			anim_player = _find_anim_player(soldier_visual)
			play_anim("Idle")
	else:
		soldier_visual = _build_fallback_human(p_ally)
		add_child(soldier_visual)

func _find_anim_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer: return node
	for c in node.get_children():
		var found = _find_anim_player(c)
		if found != null: return found
	return null

func play_anim(state_name: String) -> void:
	if anim_player == null or is_dead or current_anim == state_name: return
	if anim_player.has_animation(state_name):
		anim_player.play(state_name, 0.22); current_anim = state_name
	elif state_name == "Walk" and anim_player.has_animation("Run"):
		anim_player.play("Run", 0.22); current_anim = "Run"

func trigger_muzzle() -> void:
	if muzzle_flash != null:
		muzzle_flash.light_energy = 4.5
		get_tree().create_timer(0.07).timeout.connect(func():
			if is_instance_valid(muzzle_flash): muzzle_flash.light_energy = 0.0
		)

func _build_fallback_human(ally_flag: bool) -> Node3D:
	var root = Node3D.new()
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.15, 0.35, 0.72) if ally_flag else Color(0.26, 0.28, 0.24)
	var body = MeshInstance3D.new(); var cap = CapsuleMesh.new(); cap.radius = 0.32; cap.height = 1.4
	body.mesh = cap; body.material_override = mat; body.position.y = 0.85
	var head = MeshInstance3D.new(); var sph = SphereMesh.new(); sph.radius = 0.2
	head.mesh = sph; head.position.y = 1.65
	root.add_child(body); root.add_child(head)
	return root

func take_damage(amount: float, hit_world_y: float) -> Dictionary:
	if is_dead: return {"killed": false, "headshot": false}
	var is_headshot = (hit_world_y - global_position.y) >= 1.42
	hp -= amount * (2.0 if is_headshot else 1.0)
	if soldier_visual != null and hp > 0.0:
		soldier_visual.rotation.x = -0.18
		get_tree().create_timer(0.14).timeout.connect(func():
			if is_instance_valid(soldier_visual) and not is_dead: soldier_visual.rotation.x = 0.0
		)
	if hp <= 0.0:
		is_dead = true
		if anim_player != null: anim_player.stop()
		var tw = create_tween()
		tw.tween_property(self, "rotation:x", -PI * 0.48, 0.35)
		tw.parallel().tween_property(self, "position:y", position.y - 0.15, 0.35)
		return {"killed": true, "headshot": is_headshot}
	return {"killed": false, "headshot": is_headshot}
