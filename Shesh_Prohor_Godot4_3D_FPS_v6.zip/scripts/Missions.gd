extends RefCounted
class_name MissionsData

static func get_ally_callouts() -> Array:
	return [
		"কভার নাও! ওরা আমাদের দিকেই গুলি করছে!",
		"আমি ডান দিকটা সামলাচ্ছি, তুমি সামনে এগোও!",
		"সাবধান! পাশের টিলার আড়ালে শত্রু আছে!",
		"রিলোড করছি, আমাকে একটু কভার দাও!",
		"দারুণ শট! এভাবেই চালিয়ে যাও!"
	]

static func get_all_missions() -> Array:
	var acts = [
		{"name": "অধ্যায় ১: অন্ধকারের সূচনা", "map": "village", "envs": ["day", "sunset", "day", "fog", "sunset"]},
		{"name": "অধ্যায় ২: রক্তাক্ত শহর", "map": "city", "envs": ["day", "rain", "sunset", "night", "rain"]},
		{"name": "অধ্যায় ৩: বৃষ্টিস্নাত অরণ্য", "map": "forest", "envs": ["rain", "fog", "night", "rain", "night"]},
		{"name": "অধ্যায় ৪: ভাঙা সেতু ও প্রতিশোধ", "map": "bridge", "envs": ["sunset", "night", "fog", "rain", "sunset"]},
		{"name": "অধ্যায় ৫: শেষ প্রহর", "map": "fortress", "envs": ["night", "rain", "sunset", "night", "day"]}
	]

	var key_events = {
		1: {
			"title": "সীমান্তের প্রথম সকাল",
			"intro": [
				{"s": "মেজর আরিফ", "p": "arif", "t": "রাকিব, প্রস্তুত হও। শত্রুপক্ষ আমাদের সীমান্ত গ্রাম দখল করে নিয়েছে।"},
				{"s": "তানভীর", "p": "tanvir", "t": "ভয় পাস না বন্ধু, আমি তোর পাশেই আছি। একসাথে ঢুকব, একসাথে ফিরব।"}
			],
			"mid": {"s": "তানভীর", "p": "tanvir", "t": "বাম দিকের বাড়ির পেছনে শত্রু লুকিয়ে আছে! পিক করে গুলি করো!"},
			"outro": "প্রথম ঘাঁটি মুক্ত হয়েছে, কিন্তু যুদ্ধ কেবল শুরু।"
		},
		18: {
			"title": "তানভীরের বিদায়",
			"intro": [
				{"s": "তানভীর", "p": "tanvir", "t": "রাকিব, আমি ডান দিকটা কভার দিচ্ছি। তুই সামনে এগিয়ে যা!"},
				{"s": "রাকিব", "p": "rakib", "t": "তানভীর, একা যাস না—ওখানে স্নাইপার আছে!"}
			],
			"mid": {"s": "তানভীর (আহত)", "p": "tanvir", "t": "রাকিব... আমার সময় শেষ... মাকে বলিস... আমি পালাইনি..."},
			"outro": "তানভীর আর নেই। তার রাইফেলটা হাতে নিয়ে তুমি শপথ নিলে—এই রক্ত বৃথা যাবে না।"
		},
		38: {
			"title": "মেজর আরিফের আত্মত্যাগ",
			"intro": [
				{"s": "মেজর আরিফ", "p": "arif", "t": "সেতুটা উড়িয়ে না দিলে ওদের ট্যাংক শহরে ঢুকে পড়বে। আমি ডেটোনেটর বসাচ্ছি!"},
				{"s": "রাকিব", "p": "rakib", "t": "স্যার, আপনি বেরোতে পারবেন না!"},
				{"s": "মেজর আরিফ", "p": "arif", "t": "আমার চেয়ে দেশের মানুষের প্রাণ বড়, রাকিব। বিদায়, ছেলে..."}
			],
			"mid": {"s": "মেজর আরিফ", "p": "arif", "t": "সবাইকে বাঁচাও রাকিব... শেষ প্রহর পর্যন্ত লড়ে যাও!"},
			"outro": "সেতু ভেঙে পড়ল, সাথে হারিয়ে গেলেন তোমাদের পিতৃতুল্য কমান্ডার মেজর আরিফ।"
		},
		50: {
			"title": "শেষ প্রহর (চূড়ান্ত যুদ্ধ)",
			"intro": [
				{"s": "রাকিব", "p": "rakib", "t": "তানভীর, মেজর আরিফ—আজকের এই লড়াই তোমাদের জন্য।"},
				{"s": "রফিক", "p": "rakib", "t": "এটাই শেষ দুর্গ, রাকিব। চলো, এই অন্ধকারের অবসান ঘটাই!"}
			],
			"mid": {"s": "শত্রু কমান্ডার", "p": "arif", "t": "তুমি একা আমাদের থামাতে পারবে না!"},
			"outro": "সূর্য উঠছে। যুদ্ধ শেষ। হারানো বন্ধুদের স্মৃতি বুকে নিয়ে নতুন সকালের পথে হাঁটছ তুমি..."
		}
	}

	var list: Array = []
	for i in range(1, 51):
		var act_idx = int((i - 1) / 10)
		var act = acts[act_idx]
		var env = act["envs"][(i - 1) % act["envs"].size()]
		var ally_name = "তানভীর" if i < 18 else ("মেজর আরিফ" if i < 38 else "রফিক")
		var ally_p = "tanvir" if i < 18 else ("arif" if i < 38 else "rakib")
		var enemy_count = mini(26, 4 + int(i * 0.42))
		var enemy_hp = 75 + i * 4
		var enemy_spd = 2.6 + minf(2.6, i * 0.04)

		var custom = key_events.get(i, null)
		var title = custom["title"] if custom != null else ("অভিযান %d: %s" % [i, act["name"].split(":")[1].strip_edges()])
		var intro = custom["intro"] if custom != null else [
			{"s": ally_name, "p": ally_p, "t": "মিশন %d শুরু হচ্ছে। স্যান্ডব্যাগ ও টিলার আড়ালে কভার নাও!" % i},
			{"s": "রাকিব", "p": "rakib", "t": "ঠিক আছে, শত্রুদের একজনও যেন পালাতে না পারে!"}
		]
		var mid = custom["mid"] if custom != null else {"s": ally_name, "p": ally_p, "t": "অর্ধেক শত্রু শেষ! বাকিদের ওপর চাপ বাড়াও!"}
		var outro = custom["outro"] if custom != null else ("মিশন %d সফলভাবে সম্পন্ন হয়েছে। চেকপয়েন্ট সংরক্ষিত।" % i)

		list.append({
			"id": i, "act": act["name"], "map": act["map"], "env": env,
			"title": title, "enemies": enemy_count, "enemy_hp": enemy_hp,
			"enemy_speed": enemy_spd, "ally_name": ally_name,
			"intro": intro, "mid": mid, "outro": outro
		})
	return list
