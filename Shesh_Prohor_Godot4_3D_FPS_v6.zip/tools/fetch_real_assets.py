import os
import json
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKY_DIR = os.path.join(ROOT, "assets", "sky")
TEX_DIR = os.path.join(ROOT, "assets", "textures")
MOD_DIR = os.path.join(ROOT, "assets", "models")
FONT_DIR = os.path.join(ROOT, "assets", "fonts")
for d in [SKY_DIR, TEX_DIR, MOD_DIR, FONT_DIR]:
    os.makedirs(d, exist_ok=True)

HEADERS = {"User-Agent": "SheshProhorFPSBuilder/6.0"}

def fetch_json(url):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=25) as r:
        return json.loads(r.read().decode("utf-8"))

def download(url, dest):
    if os.path.exists(dest) and os.path.getsize(dest) > 5000:
        print("Using custom/cached file:", os.path.basename(dest))
        return True
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=45) as r:
            with open(dest, "wb") as f:
                f.write(r.read())
        print("Downloaded:", os.path.basename(dest), os.path.getsize(dest), "bytes")
        return True
    except Exception as e:
        print("Skip/Fallback for", os.path.basename(dest), "->", e)
        return False

# 1. Real Poly Haven CC0 1K HDR Skyboxes
hdr_map = {
    "sky_day.hdr": "kloofendal_48d_partly_cloudy_puresky",
    "sky_sunset.hdr": "kiara_1_dawn",
    "sky_rain.hdr": "overcast_soil_puresky",
    "sky_night.hdr": "dikhololo_night",
}
for out_name, asset_id in hdr_map.items():
    try:
        data = fetch_json(f"https://api.polyhaven.com/files/{asset_id}")
        download(data["hdri"]["1k"]["hdr"]["url"], os.path.join(SKY_DIR, out_name))
    except Exception as e:
        print("HDR API skip:", asset_id, e)

# 2. Real Poly Haven CC0 1K Photoscanned PBR Textures
pbr_map = {
    "grass": "coast_sand_rocks_02",
    "asphalt": "asphalt_02",
    "brick": "red_brick",
    "concrete": "concrete_wall_008",
    "crate": "wood_planks_dirt",
}
for prefix, asset_id in pbr_map.items():
    try:
        data = fetch_json(f"https://api.polyhaven.com/files/{asset_id}")
        for map_key, out_suffix in [
            ("Diffuse", "photo_albedo.jpg"),
            ("nor_gl", "photo_normal.jpg"),
            ("Rough", "photo_roughness.jpg"),
            ("AO", "photo_ao.jpg"),
        ]:
            if map_key in data and "1k" in data[map_key] and "jpg" in data[map_key]["1k"]:
                download(data[map_key]["1k"]["jpg"]["url"], os.path.join(TEX_DIR, f"{prefix}_{out_suffix}"))
    except Exception as e:
        print("PBR API skip:", asset_id, e)

# 3. Real CC0 3D .glb Models (Rigged Human Soldier + Real Vehicle + Props)
download(
    "https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/models/gltf/Soldier.glb",
    os.path.join(MOD_DIR, "Soldier.glb"),
)
download(
    "https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/CesiumMilkTruck/glTF-Binary/CesiumMilkTruck.glb",
    os.path.join(MOD_DIR, "jeep.glb"),
)
download(
    "https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/BoxTextured/glTF-Binary/BoxTextured.glb",
    os.path.join(MOD_DIR, "crate.glb"),
)
try:
    bdata = fetch_json("https://api.polyhaven.com/files/steel_drum_01")
    if "gltf" in bdata and "1k" in bdata["gltf"] and "glb" in bdata["gltf"]["1k"]:
        download(bdata["gltf"]["1k"]["glb"]["url"], os.path.join(MOD_DIR, "barrel.glb"))
except Exception as e:
    print("Barrel model skip:", e)

# 4. Bengali Font
download(
    "https://github.com/google/fonts/raw/main/ofl/notosansbengali/NotoSansBengali%5Bwdth%2Cwght%5D.ttf",
    os.path.join(FONT_DIR, "NotoSansBengali-Regular.ttf"),
)
print("Real CC0 asset fetch completed.")
