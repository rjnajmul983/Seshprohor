# শেষ প্রহর - Godot 4.3 Full Auto-Bundled 3D FPS (Version 7.0)

## আপনাকে আলাদা করে কোনো ৩ডি মডেল ডাউনলোড করতে হবে না!
- **ZIP-এর ভেতরেই ১০টি সম্পূর্ণ ৩ডি `.glb` মডেল যুক্ত করা আছে:** `fps_arms.glb`, `ak47.glb`, `sniper.glb`, `shotgun.glb`, `pistol.glb`, `building.glb`, `tree.glb`, `jeep.glb`, `crate.glb`, এবং `barrel.glb`।
- **বিল্ডের সময় অটোমেটিক হাই-এন্ড আপগ্রেড:** GitHub Actions বিল্ডের সময় নিজে থেকেই রিগড অ্যানিমেটেড `Soldier.glb`, Poly Haven-এর আসল ফটোস্ক্যানড PBR টেক্সচার, আসল `.hdr` স্কাইবক্স, এবং বাংলা ফন্ট ডাউনলোড করে APK তৈরি করে দেবে।
