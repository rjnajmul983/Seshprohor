import os
import json
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKY_DIR = os.path.join(ROOT, "assets", "sky")
TEX_DIR = os.path.join(ROOT, "assets", "textures")
MOD_DIR = os.path.join(ROOT, "assets", "models")
FONT_DIR = os.path.join(ROOT, "assets", "fonts")
for d in [SKY_DIR, TEX_DIR, MOD_DIR, FONT_DIR]:
    os.makedirs(d, exist_ok=True)

HEADERS = {"User-Agent": "SheshProhorFPSBuilder/7.0"}

def fetch_json(url):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=25) as r:
        return json.loads(r.read().decode("utf-8"))

def download(url, dest):
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=45) as r:
            data = r.read()
        if len(data) > 2000:
            with open(dest, "wb") as f:
                f.write(data)
            print("Downloaded:", os.path.basename(dest), len(data), "bytes")
            return True
    except Exception as e:
        print("Bundled fallback kept for", os.path.basename(dest), "->", e)
    return False

# 1. Real Poly Haven CC0 1K HDR Skyboxes
for out_name, asset_id in {
    "sky_day.hdr": "kloofendal_48d_partly_cloudy_puresky",
    "sky_sunset.hdr": "kiara_1_dawn",
    "sky_rain.hdr": "overcast_soil_puresky",
    "sky_night.hdr": "dikhololo_night",
}.items():
    try:
        data = fetch_json(f"https://api.polyhaven.com/files/{asset_id}")
        download(data["hdri"]["1k"]["hdr"]["url"], os.path.join(SKY_DIR, out_name))
    except Exception as e:
        print("HDR skip:", asset_id, e)

# 2. Real Poly Haven CC0 1K Photoscanned PBR Textures
for prefix, asset_id in {
    "grass": "coast_sand_rocks_02",
    "asphalt": "asphalt_02",
    "brick": "red_brick",
    "concrete": "concrete_wall_008",
    "crate": "wood_planks_dirt",
}.items():
    try:
        data = fetch_json(f"https://api.polyhaven.com/files/{asset_id}")
        for map_key, out_suffix in [
            ("Diffuse", "photo_albedo.jpg"),
            ("nor_gl", "photo_normal.jpg"),
            ("Rough", "photo_roughness.jpg"),
            ("AO", "photo_ao.jpg"),
        ]:
            if map_key in data and "1k" in data[map_key] and "jpg" in data[map_key]["1k"]:
                download(data[map_key]["1k"]["jpg"]["url"], os.path.join(TEX_DIR, f"{prefix}_{out_suffix}"))
    except Exception as e:
        print("PBR skip:", asset_id, e)

# 3. Real Rigged Animated 3D Human Soldier (Soldier.glb)
download(
    "https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/models/gltf/Soldier.glb",
    os.path.join(MOD_DIR, "Soldier.glb"),
)

# 4. Upgrade Props with Poly Haven Photoscanned CC0 3D .glb Models (when available)
for target_name, ph_slug in [
    ("barrel.glb", "steel_drum_01"),
    ("crate.glb", "wooden_crate_01"),
]:
    try:
        mdata = fetch_json(f"https://api.polyhaven.com/files/{ph_slug}")
        if "gltf" in mdata and "1k" in mdata["gltf"] and "glb" in mdata["gltf"]["1k"]:
            download(mdata["gltf"]["1k"]["glb"]["url"], os.path.join(MOD_DIR, target_name))
    except Exception as e:
        print("Bundled 3D model kept:", target_name, e)

# 5. Bengali Font
download(
    "https://github.com/google/fonts/raw/main/ofl/notosansbengali/NotoSansBengali%5Bwdth%2Cwght%5D.ttf",
    os.path.join(FONT_DIR, "NotoSansBengali-Regular.ttf"),
)
print("All v7 assets fetched and bundled successfully.")
