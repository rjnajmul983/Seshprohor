extends Node3D

const SAVE_PATH = "user://shesh_prohor_v7.cfg"

var missions: Array = []
var ally_callouts: Array = []
var current_mission_idx: int = 0
var unlocked_mission: int = 0
var game_state: String = "menu"

var gfx_quality: int = 2
var look_sens: float = 0.0045
var scope_sens: float = 0.0018

var weapons: Array = [
	{"id": "rifle", "glb": "ak47", "name": "AK-47 রাইফেল", "dmg": 35.0, "mag": 30, "res": 150, "rate": 0.13, "kick": 0.032},
	{"id": "sniper", "glb": "sniper", "name": "স্নাইপার রাইফেল", "dmg": 125.0, "mag": 5, "res": 30, "rate": 0.85, "kick": 0.08},
	{"id": "shotgun", "glb": "shotgun", "name": "শটগান", "dmg": 85.0, "mag": 8, "res": 40, "rate": 0.62, "kick": 0.065},
	{"id": "pistol", "glb": "pistol", "name": "৯মিমি পিস্তল", "dmg": 28.0, "mag": 15, "res": 90, "rate": 0.25, "kick": 0.025}
]
var weapon_idx: int = 0
var ammo: int = 30
var reserve_ammo: int = 150
var grenade_count: int = 3
var player_hp: float = 100.0
var is_crouching: bool = false
var is_sprinting: bool = false
var is_ads: bool = false
var is_reloading: bool = false
var is_firing_held: bool = false
var peek_dir: int = 0
var shot_cooldown: float = 0.0
var shake_strength: float = 0.0
var bob_time: float = 0.0
var step_timer: float = 0.0
var heartbeat_timer: float = 0.0
var lightning_timer: float = 6.0
var callout_timer: float = 9.0
var current_env_name: String = "day"
var current_map_type: String = "village"

var world_root: Node3D
var sun_light: DirectionalLight3D
var world_env_node: WorldEnvironment
var player_body: CharacterBody3D
var cam_pivot: Node3D
var camera: Camera3D
var weapon_rig: Node3D
var weapon_models: Dictionary = {}
var muzzle_light: OmniLight3D
var muzzle_smoke: CPUParticles3D
var rain_particles: CPUParticles3D
var ember_particles: CPUParticles3D
var audio_mgr: AudioManager

var enemies: Array = []
var ally: SoldierUnit = null
var grenades: Array = []
var active_decals: Array = []
var total_mission_enemies: int = 0
var mid_triggered: bool = false

var joy_touch_id: int = -1
var joy_center: Vector2 = Vector2(120, 580)
var joy_vec: Vector2 = Vector2.ZERO
var look_touch_id: int = -1
var look_last_pos: Vector2 = Vector2.ZERO
var yaw: float = 0.0
var pitch: float = 0.0
var sway_offset: Vector2 = Vector2.ZERO

var ui_layer: CanvasLayer
var menu_panel: Control
var settings_panel: Control
var mission_panel: Control
var mission_grid: GridContainer
var story_panel: Control
var story_act_lbl: Label
var story_title_lbl: Label
var story_speaker_lbl: Label
var story_text_lbl: Label
var story_portrait: TextureRect
var story_next_btn: Button
var story_queue: Array = []
var story_index: int = 0

var result_panel: Control
var result_title_lbl: Label
var result_desc_lbl: Label
var next_mission_btn: Button

var hud_root: Control
var hud_mission_lbl: Label
var hud_obj_lbl: Label
var hud_hp_bar: ProgressBar
var hud_weapon_lbl: Label
var hud_ammo_lbl: Label
var hud_grenade_btn: Button
var hud_subtitle_panel: PanelContainer
var hud_sub_lbl: Label
var hud_hit_lbl: Label
var hud_scope: ColorRect
var hud_damage_flash: ColorRect
var hud_low_hp_vignette: ColorRect
var joy_base: Control
var joy_knob: Control

var portraits: Dictionary = {}
var decal_bullet_tex: Texture2D
var decal_scorch_tex: Texture2D

func _ready() -> void:
	missions = MissionsData.get_all_missions()
	ally_callouts = MissionsData.get_ally_callouts()
	_load_save()
	audio_mgr = AudioManager.new(); add_child(audio_mgr)
	portraits["rakib"] = _safe_load_tex("res://assets/art/portrait_rakib.jpg")
	portraits["tanvir"] = _safe_load_tex("res://assets/art/portrait_tanvir.jpg")
	portraits["arif"] = _safe_load_tex("res://assets/art/portrait_arif.jpg")
	decal_bullet_tex = _safe_load_tex("res://assets/textures/decal_bullet.png")
	decal_scorch_tex = _safe_load_tex("res://assets/textures/decal_scorch.png")
	world_root = Node3D.new(); add_child(world_root)
	_setup_player(); _setup_ui(); _apply_graphics_quality(); _show_menu()

func _safe_load_tex(path: String) -> Texture2D:
	if ResourceLoader.exists(path): return load(path)
	return null

func _get_terrain_height(x: float, z: float) -> float:
	if current_map_type == "city" or current_map_type == "bridge": return 0.0
	var dist = Vector2(x, z).length()
	if dist < 10.0: return 0.0
	var edge_blend = clampf((dist - 10.0) / 14.0, 0.0, 1.0)
	return (sin(x * 0.065) * cos(z * 0.065) * 2.2 + sin((x + z) * 0.12) * 0.65) * edge_blend

func _load_save() -> void:
	var cfg = ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		current_mission_idx = int(cfg.get_value("progress", "current", 0))
		unlocked_mission = int(cfg.get_value("progress", "unlocked", 0))
		gfx_quality = int(cfg.get_value("settings", "gfx", 2))
		look_sens = float(cfg.get_value("settings", "look_sens", 0.0045))
		scope_sens = float(cfg.get_value("settings", "scope_sens", 0.0018))

func _write_save() -> void:
	var cfg = ConfigFile.new()
	cfg.set_value("progress", "current", current_mission_idx)
	cfg.set_value("progress", "unlocked", unlocked_mission)
	cfg.set_value("settings", "gfx", gfx_quality)
	cfg.set_value("settings", "look_sens", look_sens)
	cfg.set_value("settings", "scope_sens", scope_sens)
	cfg.save(SAVE_PATH)

func _apply_graphics_quality() -> void:
	var vp = get_viewport()
	if gfx_quality == 0: vp.scaling_3d_scale = 0.72
	elif gfx_quality == 1: vp.scaling_3d_scale = 0.88
	else: vp.scaling_3d_scale = 1.0
	if is_instance_valid(sun_light): sun_light.shadow_enabled = (gfx_quality >= 1)

func _setup_player() -> void:
	player_body = CharacterBody3D.new()
	var col = CollisionShape3D.new(); var cap = CapsuleShape3D.new(); cap.radius = 0.45; cap.height = 1.72
	col.shape = cap; col.position.y = 0.9; player_body.add_child(col)
	cam_pivot = Node3D.new(); cam_pivot.position.y = 1.65; player_body.add_child(cam_pivot)
	camera = Camera3D.new(); camera.fov = 72.0; camera.far = 380.0; cam_pivot.add_child(camera)

	rain_particles = CPUParticles3D.new(); rain_particles.emitting = false; rain_particles.amount = 240; rain_particles.lifetime = 0.85
	rain_particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX; rain_particles.emission_box_extents = Vector3(14, 1, 14)
	rain_particles.direction = Vector3(0, -1, 0); rain_particles.spread = 4.0; rain_particles.initial_velocity_min = 24.0; rain_particles.initial_velocity_max = 30.0
	var r_mesh = BoxMesh.new(); r_mesh.size = Vector3(0.02, 0.55, 0.02)
	var r_mat = StandardMaterial3D.new(); r_mat.albedo_color = Color(0.75, 0.84, 0.95, 0.55); r_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	r_mesh.material = r_mat; rain_particles.mesh = r_mesh; rain_particles.position = Vector3(0, 12, 0); player_body.add_child(rain_particles)

	ember_particles = CPUParticles3D.new(); ember_particles.emitting = true; ember_particles.amount = 75; ember_particles.lifetime = 4.5
	ember_particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX; ember_particles.emission_box_extents = Vector3(18, 6, 18)
	ember_particles.direction = Vector3(0.4, 0.6, 0.2); ember_particles.spread = 45.0; ember_particles.gravity = Vector3(0, 0.15, 0)
	ember_particles.initial_velocity_min = 0.4; ember_particles.initial_velocity_max = 1.3
	var e_mesh = SphereMesh.new(); e_mesh.radius = 0.035
	var e_mat = StandardMaterial3D.new(); e_mat.albedo_color = Color(1.0, 0.55, 0.15); e_mat.emission_enabled = true; e_mat.emission = Color(1.0, 0.45, 0.1); e_mat.emission_energy_multiplier = 3.2
	e_mesh.material = e_mat; ember_particles.mesh = e_mesh; ember_particles.position = Vector3(0, 3.0, 0); player_body.add_child(ember_particles)

	weapon_rig = Node3D.new()
	_build_all_weapon_models()

	muzzle_light = OmniLight3D.new(); muzzle_light.light_color = Color(1.0, 0.72, 0.25); muzzle_light.light_energy = 0.0
	muzzle_light.omni_range = 10.0; muzzle_light.position = Vector3(0.24, -0.19, -0.92); weapon_rig.add_child(muzzle_light)

	muzzle_smoke = CPUParticles3D.new(); muzzle_smoke.emitting = false; muzzle_smoke.one_shot = true; muzzle_smoke.amount = 10; muzzle_smoke.lifetime = 0.35
	muzzle_smoke.explosiveness = 0.9; muzzle_smoke.direction = Vector3(0, 0.4, -1); muzzle_smoke.spread = 28.0; muzzle_smoke.initial_velocity_min = 1.5; muzzle_smoke.initial_velocity_max = 3.5
	var sm_mesh = SphereMesh.new(); sm_mesh.radius = 0.04; var sm_mat = StandardMaterial3D.new(); sm_mat.albedo_color = Color(0.85, 0.85, 0.85, 0.45); sm_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm_mesh.material = sm_mat; muzzle_smoke.mesh = sm_mesh; muzzle_smoke.position = Vector3(0.24, -0.19, -0.88); weapon_rig.add_child(muzzle_smoke)

	camera.add_child(weapon_rig)
	add_child(player_body)

func _build_all_weapon_models() -> void:
	# Load Bundled Sculpted Human FPS Arms (.glb)
	var fps_arms_glb = AssetLoader.instantiate_glb("fps_arms", 0.35, false)
	if fps_arms_glb != null:
		fps_arms_glb.position = Vector3(0.0, -0.44, -0.24)
		weapon_rig.add_child(fps_arms_glb)

	for w in weapons:
		var wid = w["id"]
		var root = Node3D.new()
		var w_glb = AssetLoader.instantiate_glb(w["glb"], 0.24, false)
		if w_glb != null:
			w_glb.position = Vector3(0.24, -0.32, -0.46)
			w_glb.rotation.y = PI
			root.add_child(w_glb)
		root.visible = (wid == "rifle")
		weapon_rig.add_child(root)
		weapon_models[wid] = root

func _build_terrain(ground_mat: Material) -> void:
	var st = SurfaceTool.new(); st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var grid = 44; var size = 180.0; var step = size / float(grid); var half = size * 0.5
	for gz in range(grid):
		for gx in range(grid):
			var x0 = -half + gx * step; var z0 = -half + gz * step; var x1 = x0 + step; var z1 = z0 + step
			var p00 = Vector3(x0, _get_terrain_height(x0, z0), z0); var p10 = Vector3(x1, _get_terrain_height(x1, z0), z0)
			var p01 = Vector3(x0, _get_terrain_height(x0, z1), z1); var p11 = Vector3(x1, _get_terrain_height(x1, z1), z1)
			var u0 = float(gx)/float(grid); var v0 = float(gz)/float(grid); var u1 = float(gx+1)/float(grid); var v1 = float(gz+1)/float(grid)
			st.set_uv(Vector2(u0, v0)); st.add_vertex(p00); st.set_uv(Vector2(u1, v0)); st.add_vertex(p10); st.set_uv(Vector2(u0, v1)); st.add_vertex(p01)
			st.set_uv(Vector2(u1, v0)); st.add_vertex(p10); st.set_uv(Vector2(u1, v1)); st.add_vertex(p11); st.set_uv(Vector2(u0, v1)); st.add_vertex(p01)
	st.generate_normals(); var arr_mesh = st.commit()
	var ground = StaticBody3D.new(); var mi = MeshInstance3D.new(); mi.mesh = arr_mesh; mi.material_override = ground_mat
	var col = CollisionShape3D.new(); col.shape = arr_mesh.create_trimesh_shape()
	ground.add_child(mi); ground.add_child(col); world_root.add_child(ground)

func _build_wind_grass() -> void:
	if current_map_type == "city" or current_map_type == "bridge": return
	var grass_count = 650 if gfx_quality == 0 else (1400 if gfx_quality == 1 else 2400)
	var mm_inst = MultiMeshInstance3D.new(); var mm = MultiMesh.new(); mm.transform_format = MultiMesh.TRANSFORM_3D; mm.instance_count = grass_count
	var blade = QuadMesh.new(); blade.size = Vector2(0.55, 0.72)
	var sh = Shader.new()
	sh.code = """
shader_type spatial;
render_mode cull_disabled;
void vertex() {
	float wind = sin(TIME * 2.6 + NODE_POSITION_WORLD.x * 0.4 + NODE_POSITION_WORLD.z * 0.35) * 0.16;
	VERTEX.x += wind * (1.0 - UV.y);
}
void fragment() {
	vec3 base_col = mix(vec3(0.10, 0.24, 0.08), vec3(0.24, 0.44, 0.14), 1.0 - UV.y);
	ALBEDO = base_col; ROUGHNESS = 0.85;
	if (abs(UV.x - 0.5) * 2.0 > (UV.y * 0.9 + 0.12)) discard;
}
"""
	var sh_mat = ShaderMaterial.new(); sh_mat.shader = sh; blade.material = sh_mat; mm.mesh = blade
	var rng = RandomNumberGenerator.new(); rng.seed = 404 + current_mission_idx
	for i in range(grass_count):
		var gx = rng.randf_range(-58.0, 58.0); var gz = rng.randf_range(-58.0, 58.0)
		var gy = _get_terrain_height(gx, gz) + 0.32
		var b = Basis(Vector3.UP, rng.randf_range(0.0, TAU)).scaled(Vector3.ONE * rng.randf_range(0.75, 1.35))
		mm.set_instance_transform(i, Transform3D(b, Vector3(gx, gy, gz)))
	mm_inst.multimesh = mm; mm_inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF; world_root.add_child(mm_inst)

func _spawn_decal(pos: Vector3, normal: Vector3, is_scorch: bool) -> void:
	var d = Decal.new(); d.texture_albedo = decal_scorch_tex if is_scorch else decal_bullet_tex
	d.size = Vector3(3.6, 1.2, 3.6) if is_scorch else Vector3(0.32, 0.32, 0.32); d.position = pos + normal * 0.02
	world_root.add_child(d)
	if absf(normal.y) < 0.9: d.look_at(pos + normal, Vector3.UP); d.rotate_object_local(Vector3.RIGHT, PI * 0.5)
	active_decals.append(d)
	if active_decals.size() > 40:
		var old = active_decals.pop_front()
		if is_instance_valid(old): old.queue_free()

func _build_environment(env_name: String, map_type: String) -> void:
	for c in world_root.get_children(): c.queue_free()
	enemies.clear(); grenades.clear(); active_decals.clear(); ally = null
	current_env_name = env_name; current_map_type = map_type
	var is_wet = (env_name == "rain")
	rain_particles.emitting = is_wet
	ember_particles.emitting = (env_name == "sunset" or env_name == "night" or map_type == "fortress")

	world_env_node = WorldEnvironment.new()
	var env = Environment.new(); var sky = Sky.new(); var sky_mat = PanoramaSkyMaterial.new()
	sky_mat.panorama = AssetLoader.load_sky_texture(env_name); sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY; env.sky = sky; env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.glow_enabled = true; env.glow_intensity = 0.65; env.glow_bloom = 0.22; env.glow_hdr_threshold = 0.95
	env.adjustment_enabled = true; env.adjustment_contrast = 1.08
	env.adjustment_saturation = 0.92 if (env_name == "rain" or env_name == "night") else 1.12
	env.fog_enabled = true; env.fog_density = 0.024 if env_name == "fog" else (0.012 if is_wet else 0.005)
	env.fog_height = 2.5; env.fog_height_density = 0.35

	sun_light = DirectionalLight3D.new(); sun_light.shadow_enabled = (gfx_quality >= 1); sun_light.rotation_degrees = Vector3(-46, 32, 0)
	if env_name == "night": sun_light.light_energy = 0.38; sun_light.light_color = Color(0.65, 0.78, 1.0)
	elif env_name == "sunset": sun_light.light_energy = 1.35; sun_light.light_color = Color(1.0, 0.66, 0.36)
	elif is_wet or env_name == "fog": sun_light.light_energy = 0.68
	else: sun_light.light_energy = 1.30
	world_env_node.environment = env; world_root.add_child(world_env_node); world_root.add_child(sun_light)

	var g_prefix = "asphalt" if (map_type == "city" or map_type == "bridge") else "grass"
	_build_terrain(AssetLoader.make_pbr_material(g_prefix, 24.0, is_wet))
	_build_wind_grass()

	var sandbag_mat = StandardMaterial3D.new(); sandbag_mat.albedo_color = Color(0.56, 0.50, 0.36); sandbag_mat.roughness = 0.95

	# All Environment Objects now use Bundled .glb Models!
	var b_count = 6 if map_type == "forest" else 16
	for i in range(b_count):
		var ang = (float(i) / float(b_count)) * TAU; var dist = 24.0 + float(i % 3) * 16.0
		var bx = cos(ang) * dist; var bz = sin(ang) * dist; var by = _get_terrain_height(bx, bz)
		var h = (11.0 + float(i % 4) * 4.5) if map_type == "city" else (6.5 + float(i % 3) * 2.2)
		var b_glb = AssetLoader.instantiate_glb("building", h, true)
		if b_glb != null:
			b_glb.position = Vector3(bx, by - 0.3, bz); b_glb.rotation.y = ang; world_root.add_child(b_glb)

	var rng = RandomNumberGenerator.new(); rng.seed = current_mission_idx * 101 + 13
	for i in range(14):
		var cx = rng.randf_range(-34.0, 34.0); var cz = rng.randf_range(-34.0, 34.0)
		if Vector2(cx, cz).length() < 7.0: continue
		var cy = _get_terrain_height(cx, cz)
		if i % 3 == 0:
			var c_glb = AssetLoader.instantiate_glb("crate", 1.35, true)
			if c_glb != null: c_glb.position = Vector3(cx, cy, cz); c_glb.rotation.y = rng.randf_range(0, TAU); world_root.add_child(c_glb)
		elif i % 3 == 1:
			var br_glb = AssetLoader.instantiate_glb("barrel", 1.25, true)
			if br_glb != null: br_glb.position = Vector3(cx, cy, cz); world_root.add_child(br_glb)
		else:
			_spawn_sandbag_wall(Vector3(cx, cy, cz), rng.randf_range(0, PI), sandbag_mat)

	for i in range(4):
		var vx = (float(i) - 1.5) * 15.0; var vz = -18.0 - float(i % 2) * 14.0
		var j_glb = AssetLoader.instantiate_glb("jeep", 2.2, true)
		if j_glb != null: j_glb.position = Vector3(vx, _get_terrain_height(vx, vz), vz); j_glb.rotation.y = i * 0.7; world_root.add_child(j_glb)

	var t_count = 46 if map_type == "forest" else 18
	for i in range(t_count):
		var tx = rng.randf_range(-68.0, 68.0); var tz = rng.randf_range(-68.0, 68.0)
		if Vector2(tx, tz).length() < 11.0: continue
		var t_glb = AssetLoader.instantiate_glb("tree", rng.randf_range(5.5, 8.5), false)
		if t_glb != null: t_glb.position = Vector3(tx, _get_terrain_height(tx, tz) - 0.2, tz); t_glb.rotation.y = rng.randf_range(0, TAU); world_root.add_child(t_glb)

func _spawn_sandbag_wall(pos: Vector3, rot_y: float, mat: Material) -> void:
	var wall = StaticBody3D.new(); wall.position = pos; wall.rotation.y = rot_y
	for row in range(3):
		for col_i in range(4):
			var bag = MeshInstance3D.new(); var cap = CapsuleMesh.new(); cap.radius = 0.22; cap.height = 0.9
			bag.mesh = cap; bag.material_override = mat; bag.rotation.z = PI * 0.5
			bag.position = Vector3((float(col_i) - 1.5) * 0.85, 0.22 + float(row) * 0.38, 0); wall.add_child(bag)
	var col = CollisionShape3D.new(); var bs = BoxShape3D.new(); bs.size = Vector3(3.6, 1.25, 0.6)
	col.shape = bs; col.position.y = 0.62; wall.add_child(col); world_root.add_child(wall)

func _spawn_impact_vfx(pos: Vector3, is_blood: bool) -> void:
	var p = CPUParticles3D.new(); p.position = pos; p.one_shot = true; p.explosiveness = 0.95; p.amount = 14; p.lifetime = 0.35; p.spread = 180.0
	p.initial_velocity_min = 2.0; p.initial_velocity_max = 6.5
	var m = SphereMesh.new(); m.radius = 0.045; var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.72, 0.06, 0.06) if is_blood else Color(1.0, 0.82, 0.30)
	if not is_blood: mat.emission_enabled = true; mat.emission = Color(1.0, 0.7, 0.2); mat.emission_energy_multiplier = 3.0
	m.material = mat; p.mesh = m; world_root.add_child(p); p.emitting = true
	get_tree().create_timer(0.6).timeout.connect(func(): if is_instance_valid(p): p.queue_free())

func _spawn_explosion_vfx(pos: Vector3) -> void:
	_spawn_decal(Vector3(pos.x, _get_terrain_height(pos.x, pos.z), pos.z), Vector3.UP, true)
	for is_smoke in [false, true]:
		var p = CPUParticles3D.new(); p.position = pos; p.one_shot = true; p.explosiveness = 0.9
		p.amount = 28 if not is_smoke else 22; p.lifetime = 0.65 if not is_smoke else 1.4; p.spread = 180.0
		p.initial_velocity_min = 4.0 if not is_smoke else 1.5; p.initial_velocity_max = 12.0 if not is_smoke else 4.5
		p.gravity = Vector3(0, 3.0 if is_smoke else -4.0, 0)
		var m = SphereMesh.new(); m.radius = 0.22 if not is_smoke else 0.42; var mat = StandardMaterial3D.new()
		mat.albedo_color = Color(0.16, 0.16, 0.18, 0.72) if is_smoke else Color(1.0, 0.45, 0.08)
		if not is_smoke: mat.emission_enabled = true; mat.emission = Color(1.0, 0.42, 0.05); mat.emission_energy_multiplier = 4.5
		else: mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.material = mat; p.mesh = m; world_root.add_child(p); p.emitting = true
		get_tree().create_timer(1.8).timeout.connect(func(): if is_instance_valid(p): p.queue_free())

func _spawn_tracer(from_p: Vector3, to_p: Vector3, col: Color) -> void:
	var mi = MeshInstance3D.new(); var bm = BoxMesh.new(); bm.size = Vector3(0.03, 0.03, from_p.distance_to(to_p))
	var mat = StandardMaterial3D.new(); mat.albedo_color = col; mat.emission_enabled = true; mat.emission = col; mat.emission_energy_multiplier = 3.5
	mi.mesh = bm; mi.material_override = mat; mi.position = (from_p + to_p) * 0.5; world_root.add_child(mi); mi.look_at(to_p, Vector3.UP)
	get_tree().create_timer(0.06).timeout.connect(func(): if is_instance_valid(mi): mi.queue_free())

func _spawn_units(m: Dictionary) -> void:
	ally = SoldierUnit.new(); ally.setup(280.0, 4.4, true)
	ally.position = Vector3(3.0, _get_terrain_height(3.0, -2.5) + 0.2, -2.5); world_root.add_child(ally)
	total_mission_enemies = int(m["enemies"])
	var rng = RandomNumberGenerator.new(); rng.randomize()
	for i in range(total_mission_enemies):
		var u = SoldierUnit.new(); u.setup(float(m["enemy_hp"]), float(m["enemy_speed"]), false)
		var ang = rng.randf_range(0.0, TAU); var dist = rng.randf_range(22.0, 54.0)
		var ex = cos(ang) * dist; var ez = sin(ang) * dist
		u.position = Vector3(ex, _get_terrain_height(ex, ez) + 0.2, ez); world_root.add_child(u); enemies.append(u)

func _start_story(idx: int) -> void:
	current_mission_idx = clampi(idx, 0, 49); var m = missions[current_mission_idx]; game_state = "story"
	menu_panel.visible = false; settings_panel.visible = false; mission_panel.visible = false; result_panel.visible = false; hud_root.visible = false; story_panel.visible = true
	story_act_lbl.text = m["act"]; story_title_lbl.text = "মিশন %d: %s" % [m["id"], m["title"]]
	story_queue = m["intro"]; story_index = 0; _render_story_line()

func _render_story_line() -> void:
	var line = story_queue[story_index]
	story_speaker_lbl.text = line["s"] + ":"; story_text_lbl.text = line["t"]
	story_portrait.texture = portraits.get(line.get("p", "rakib"), null)
	story_next_btn.text = "যুদ্ধ শুরু করুন →" if story_index == story_queue.size() - 1 else "পরবর্তী →"

func _start_gameplay() -> void:
	var m = missions[current_mission_idx]; story_panel.visible = false; hud_root.visible = true; game_state = "playing"; mid_triggered = false
	player_hp = 100.0; grenade_count = 3; yaw = 0.0; pitch = 0.0; peek_dir = 0
	_equip_weapon(0); _build_environment(m["env"], m["map"])
	player_body.position = Vector3(0, _get_terrain_height(0, 0) + 0.4, 0)
	_spawn_units(m); hud_mission_lbl.text = "মিশন %d: %s" % [m["id"], m["title"]]; _update_hud(); _show_subtitle(m["intro"][0]["s"], m["intro"][0]["t"])

func _equip_weapon(idx: int) -> void:
	weapon_idx = idx % weapons.size(); var w = weapons[weapon_idx]; ammo = int(w["mag"]); reserve_ammo = int(w["res"])
	for wid in weapon_models.keys(): weapon_models[wid].visible = (wid == w["id"])
	_update_hud()

func _update_hud() -> void:
	var w = weapons[weapon_idx]
	hud_hp_bar.value = maxf(0.0, player_hp); hud_weapon_lbl.text = w["name"]
	hud_ammo_lbl.text = "%d / %d" % [ammo, reserve_ammo]; hud_grenade_btn.text = "গ্রেনেড (%d)" % grenade_count
	hud_obj_lbl.text = "শত্রু বাকি: %d" % enemies.size()
	hud_low_hp_vignette.color = Color(0.65, 0.0, 0.0, 0.26 if player_hp < 32.0 else 0.0)

func _show_subtitle(speaker: String, text: String) -> void:
	hud_sub_lbl.text = "%s: %s" % [speaker, text]; hud_subtitle_panel.visible = true
	get_tree().create_timer(4.2).timeout.connect(func(): hud_subtitle_panel.visible = false)

func _fire_weapon() -> void:
	if game_state != "playing" or is_reloading or shot_cooldown > 0.0: return
	if ammo <= 0: _reload_weapon(); return
	var w = weapons[weapon_idx]; shot_cooldown = float(w["rate"]); ammo -= 1; audio_mgr.play_2d(w["id"])
	pitch = minf(1.2, pitch + float(w["kick"]) * 0.5); shake_strength = maxf(shake_strength, float(w["kick"]) * 1.4)
	weapon_rig.position.z = 0.08; muzzle_light.light_energy = 6.0; muzzle_smoke.restart(); muzzle_smoke.emitting = true
	get_tree().create_timer(0.065).timeout.connect(func(): weapon_rig.position.z = 0.0; muzzle_light.light_energy = 0.0)

	var space = get_world_3d().direct_space_state
	var from = camera.global_position; var to = from - camera.global_transform.basis.z * 165.0
	var query = PhysicsRayQueryParameters3D.create(from, to); query.exclude = [player_body]
	var hit = space.intersect_ray(query)
	if hit.size() > 0:
		var collider = hit["collider"]; var hit_pos: Vector3 = hit["position"]; var hit_norm: Vector3 = hit["normal"]
		if collider is SoldierUnit and not collider.is_ally:
			_spawn_impact_vfx(hit_pos, true)
			var res = collider.take_damage(float(w["dmg"]), hit_pos.y)
			audio_mgr.play_2d("headshot" if res["headshot"] else "hit")
			hud_hit_lbl.text = "হেডশট! ✕" if res["headshot"] else "✕"; hud_hit_lbl.visible = true
			get_tree().create_timer(0.18).timeout.connect(func(): hud_hit_lbl.visible = false)
			if res["killed"]: _on_enemy_killed(collider)
		else:
			_spawn_impact_vfx(hit_pos, false); _spawn_decal(hit_pos, hit_norm, false)
	_update_hud()

func _on_enemy_killed(u: SoldierUnit) -> void:
	enemies.erase(u); get_tree().create_timer(3.2).timeout.connect(func(): if is_instance_valid(u): u.queue_free())
	var m = missions[current_mission_idx]
	if not mid_triggered and enemies.size() <= int(total_mission_enemies / 2):
		mid_triggered = true; _show_subtitle(m["mid"]["s"], m["mid"]["t"])
	if enemies.size() == 0: _mission_success()
	_update_hud()

func _reload_weapon() -> void:
	if is_reloading: return
	var w = weapons[weapon_idx]
	if ammo == int(w["mag"]) or reserve_ammo <= 0: return
	is_reloading = true; audio_mgr.play_2d("reload")
	var tw = create_tween(); tw.tween_property(weapon_rig, "rotation:x", -0.55, 0.25); tw.tween_interval(0.45); tw.tween_property(weapon_rig, "rotation:x", 0.0, 0.25)
	get_tree().create_timer(0.95).timeout.connect(func():
		var need = int(w["mag"]) - ammo; var take = mini(need, reserve_ammo)
		ammo += take; reserve_ammo -= take; is_reloading = false; _update_hud()
	)

func _throw_grenade() -> void:
	if game_state != "playing" or grenade_count <= 0: return
	grenade_count -= 1; _update_hud()
	var g = MeshInstance3D.new(); var sph = SphereMesh.new(); sph.radius = 0.14; g.mesh = sph; g.position = camera.global_position; world_root.add_child(g)
	grenades.append({"node": g, "vel": (-camera.global_transform.basis.z + Vector3(0, 0.28, 0)).normalized() * 17.0, "timer": 1.6})

func _mission_success() -> void:
	game_state = "result"; var m = missions[current_mission_idx]
	if current_mission_idx + 1 > unlocked_mission and current_mission_idx + 1 < 50: unlocked_mission = current_mission_idx + 1
	current_mission_idx = mini(49, current_mission_idx + 1); _write_save()
	hud_root.visible = false; result_panel.visible = true
	result_title_lbl.text = "মিশন %d সম্পন্ন! (চেকপয়েন্ট সেভড)" % m["id"]; result_desc_lbl.text = m["outro"]; next_mission_btn.visible = (m["id"] < 50)

func _mission_failed() -> void:
	game_state = "result"; hud_root.visible = false; result_panel.visible = true
	result_title_lbl.text = "আপনি শহীদ হয়েছেন"; result_desc_lbl.text = "হাল ছাড়বেন না—চেকপয়েন্ট থেকে আবার লড়াই শুরু করুন।"; next_mission_btn.visible = false

func _physics_process(delta: float) -> void:
	if game_state != "playing": return
	if shot_cooldown > 0.0: shot_cooldown -= delta
	if is_firing_held: _fire_weapon()

	if current_env_name == "rain":
		lightning_timer -= delta
		if lightning_timer <= 0.0:
			lightning_timer = randf_range(7.0, 14.0)
			if is_instance_valid(sun_light):
				sun_light.light_energy = 4.5; audio_mgr.play_2d("thunder")
				get_tree().create_timer(0.12).timeout.connect(func(): if is_instance_valid(sun_light): sun_light.light_energy = 0.68)

	if player_hp < 32.0:
		heartbeat_timer -= delta
		if heartbeat_timer <= 0.0: heartbeat_timer = 0.85; audio_mgr.play_heartbeat()

	var move_x = joy_vec.x; var move_y = joy_vec.y
	if Input.is_key_pressed(KEY_D): move_x += 1.0
	if Input.is_key_pressed(KEY_A): move_x -= 1.0
	if Input.is_key_pressed(KEY_S): move_y += 1.0
	if Input.is_key_pressed(KEY_W): move_y -= 1.0

	var spd = 3.5 if is_crouching else (9.2 if is_sprinting else 6.6)
	var dir = (Vector3(-sin(yaw), 0.0, -cos(yaw)) * -move_y + Vector3(cos(yaw), 0.0, -sin(yaw)) * move_x)
	if dir.length() > 1.0: dir = dir.normalized()
	player_body.velocity.x = dir.x * spd; player_body.velocity.z = dir.z * spd
	if not player_body.is_on_floor(): player_body.velocity.y -= 20.0 * delta
	player_body.move_and_slide()

	if dir.length() > 0.15 and player_body.is_on_floor():
		bob_time += delta * (12.0 if is_sprinting else 8.5); weapon_rig.position.y = sin(bob_time) * 0.014
		step_timer -= delta
		if step_timer <= 0.0:
			step_timer = 0.34 if is_sprinting else 0.48
			audio_mgr.play_footstep(current_map_type == "city" or current_map_type == "bridge")

	cam_pivot.position.x = lerpf(cam_pivot.position.x, float(peek_dir) * 0.55, delta * 10.0)
	cam_pivot.position.y = lerpf(cam_pivot.position.y, 1.1 if is_crouching else 1.65, delta * 10.0)
	cam_pivot.rotation.z = lerpf(cam_pivot.rotation.z, float(-peek_dir) * 0.18, delta * 10.0)

	if shake_strength > 0.001:
		camera.h_offset = randf_range(-shake_strength, shake_strength); camera.v_offset = randf_range(-shake_strength, shake_strength)
		shake_strength = lerpf(shake_strength, 0.0, delta * 9.0)
	else:
		camera.h_offset = 0.0; camera.v_offset = 0.0

	weapon_rig.position.x = lerpf(weapon_rig.position.x, sway_offset.x, delta * 8.0)
	sway_offset = sway_offset.lerp(Vector2.ZERO, delta * 8.0)
	player_body.rotation.y = yaw; cam_pivot.rotation.x = pitch

	var now = Time.get_ticks_msec() / 1000.0
	if is_instance_valid(ally) and enemies.size() > 0:
		callout_timer -= delta
		if callout_timer <= 0.0:
			callout_timer = randf_range(11.0, 18.0)
			_show_subtitle(missions[current_mission_idx]["ally_name"], ally_callouts[randi() % ally_callouts.size()])
		var to_p = (player_body.global_position + Vector3(2.8, 0, 2.2)) - ally.global_position; to_p.y = 0.0
		if to_p.length() > 3.6:
			ally.velocity.x = to_p.normalized().x * ally.move_speed; ally.velocity.z = to_p.normalized().z * ally.move_speed
			if not ally.is_on_floor(): ally.velocity.y -= 18.0 * delta
			ally.move_and_slide(); ally.play_anim("Run")
		else:
			ally.play_anim("Idle")
		var nearest: SoldierUnit = enemies[0]
		ally.look_at(Vector3(nearest.global_position.x, ally.global_position.y, nearest.global_position.z), Vector3.UP)
		if now - ally.last_shot_time > 1.75 and ally.global_position.distance_to(nearest.global_position) < 40.0:
			ally.last_shot_time = now; ally.trigger_muzzle(); audio_mgr.play_3d(world_root, ally.global_position, "rifle", 45.0)
			_spawn_tracer(ally.global_position + Vector3(0, 1.35, 0), nearest.global_position + Vector3(0, 1.2, 0), Color(0.25, 0.78, 1.0))
			if nearest.take_damage(20.0, nearest.global_position.y + 1.1)["killed"]: _on_enemy_killed(nearest)

	for e in enemies.duplicate():
		if not is_instance_valid(e) or e.is_dead: continue
		var to_player = player_body.global_position - e.global_position; to_player.y = 0.0; var dist = to_player.length()
		e.look_at(Vector3(player_body.global_position.x, e.global_position.y, player_body.global_position.z), Vector3.UP)
		e.strafe_timer -= delta
		if e.strafe_timer <= 0.0: e.strafe_timer = randf_range(1.4, 2.8); e.strafe_dir = -e.strafe_dir
		var move_dir = Vector3.ZERO
		if dist > 16.0: move_dir = to_player.normalized(); e.play_anim("Run")
		elif dist > 9.0: move_dir = (to_player.normalized().cross(Vector3.UP) * e.strafe_dir * 0.75 + to_player.normalized() * 0.25).normalized(); e.play_anim("Walk")
		else: e.play_anim("Idle")
		e.velocity.x = move_dir.x * e.move_speed; e.velocity.z = move_dir.z * e.move_speed
		if not e.is_on_floor(): e.velocity.y -= 18.0 * delta
		e.move_and_slide()
		if dist < 30.0 and now - e.last_shot_time > 1.7:
			e.last_shot_time = now; e.trigger_muzzle(); audio_mgr.play_3d(world_root, e.global_position, "rifle", 50.0)
			_spawn_tracer(e.global_position + Vector3(0, 1.35, 0), camera.global_position + Vector3(randf_range(-0.9, 0.9), -0.3, randf_range(-0.9, 0.9)), Color(1.0, 0.35, 0.15))
			if randf() < 0.48:
				player_hp -= 7.0; shake_strength = maxf(shake_strength, 0.04)
				hud_damage_flash.color = Color(0.85, 0.08, 0.08, 0.38)
				get_tree().create_timer(0.18).timeout.connect(func(): hud_damage_flash.color = Color(0.85, 0.08, 0.08, 0.0))
				_update_hud()
				if player_hp <= 0.0: _mission_failed(); return

	for i in range(grenades.size() - 1, -1, -1):
		var g = grenades[i]; g["vel"].y -= 22.0 * delta; g["node"].position += g["vel"] * delta
		var floor_y = _get_terrain_height(g["node"].position.x, g["node"].position.z) + 0.18
		if g["node"].position.y < floor_y: g["node"].position.y = floor_y; g["vel"].y *= -0.35
		g["timer"] -= delta
		if g["timer"] <= 0.0:
			var pos: Vector3 = g["node"].position
			audio_mgr.play_3d(world_root, pos, "boom", 85.0); _spawn_explosion_vfx(pos)
			if pos.distance_to(player_body.global_position) < 25.0: shake_strength = 0.28
			g["node"].queue_free(); grenades.remove_at(i)
			for e in enemies.duplicate():
				if is_instance_valid(e) and e.global_position.distance_to(pos) < 12.0:
					if e.take_damage(220.0, e.global_position.y + 1.0)["killed"]: _on_enemy_killed(e)

func _input(event: InputEvent) -> void:
	if game_state != "playing": return
	var vp_size = get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < vp_size.x * 0.32 and event.position.y > vp_size.y * 0.45:
				joy_touch_id = event.index; joy_center = joy_base.global_position + joy_base.size * 0.5
			elif event.position.x > vp_size.x * 0.32 and event.position.x < vp_size.x * 0.76:
				look_touch_id = event.index; look_last_pos = event.position
		else:
			if event.index == joy_touch_id:
				joy_touch_id = -1; joy_vec = Vector2.ZERO; joy_knob.position = (joy_base.size - joy_knob.size) * 0.5
			elif event.index == look_touch_id: look_touch_id = -1
	elif event is InputEventScreenDrag:
		if event.index == joy_touch_id:
			var clamped = (event.position - joy_center).limit_length(46.0); joy_vec = clamped / 46.0
			joy_knob.position = (joy_base.size - joy_knob.size) * 0.5 + clamped
		elif event.index == look_touch_id:
			var diff = event.position - look_last_pos; look_last_pos = event.position
			var s = scope_sens if is_ads else look_sens
			yaw -= diff.x * s; pitch = clampf(pitch - diff.y * s, -1.2, 1.2)
			sway_offset.x = clampf(-diff.x * 0.0015, -0.04, 0.04)

func _show_menu() -> void:
	game_state = "menu"; menu_panel.visible = true; settings_panel.visible = false; mission_panel.visible = false; story_panel.visible = false; result_panel.visible = false; hud_root.visible = false

func _setup_ui() -> void:
	ui_layer = CanvasLayer.new(); add_child(ui_layer)
	menu_panel = Control.new(); menu_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg_tex = TextureRect.new(); bg_tex.set_anchors_preset(Control.PRESET_FULL_RECT); bg_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; bg_tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED; bg_tex.texture = _safe_load_tex("res://assets/art/menu_bg.jpg"); menu_panel.add_child(bg_tex)
	var shade = ColorRect.new(); shade.set_anchors_preset(Control.PRESET_FULL_RECT); shade.color = Color(0.03, 0.05, 0.08, 0.55); menu_panel.add_child(shade)

	var vbox = VBoxContainer.new(); vbox.set_anchors_preset(Control.PRESET_CENTER); vbox.offset_left = -300; vbox.offset_right = 300; vbox.offset_top = -170; vbox.offset_bottom = 170; vbox.add_theme_constant_override("separation", 12)
	var title = Label.new(); title.text = "শেষ প্রহর 3D FPS"; title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size", 46); vbox.add_child(title)
	var sub = Label.new(); sub.text = "ভার্সন ৭.০ অটো-বান্ডেলড • সব ৩ডি .glb মডেল, ফটোস্ক্যানড PBR ও HDR"; sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; sub.add_theme_font_size_override("font_size", 15); vbox.add_child(sub)
	var btn_play = Button.new(); btn_play.text = "মিশন শুরু করুন"; btn_play.custom_minimum_size = Vector2(260, 54); btn_play.pressed.connect(func(): _start_story(current_mission_idx)); vbox.add_child(btn_play)
	var btn_list = Button.new(); btn_list.text = "সব মিশন দেখুন (৫০টি)"; btn_list.custom_minimum_size = Vector2(260, 46); btn_list.pressed.connect(_open_mission_list); vbox.add_child(btn_list)
	var btn_set = Button.new(); btn_set.text = "গ্রাফিক্স ও কন্ট্রোল সেটিংস"; btn_set.custom_minimum_size = Vector2(260, 46); btn_set.pressed.connect(func(): settings_panel.visible = true); vbox.add_child(btn_set)
	menu_panel.add_child(vbox); ui_layer.add_child(menu_panel)

	settings_panel = ColorRect.new(); settings_panel.set_anchors_preset(Control.PRESET_FULL_RECT); settings_panel.color = Color(0.03, 0.05, 0.09, 0.95); settings_panel.visible = false
	var st_box = VBoxContainer.new(); st_box.set_anchors_preset(Control.PRESET_CENTER); st_box.offset_left = -240; st_box.offset_right = 240; st_box.offset_top = -160; st_box.offset_bottom = 160; st_box.add_theme_constant_override("separation", 14)
	var st_title = Label.new(); st_title.text = "গ্রাফিক্স ও সেন্সিটিভিটি সেটিংস"; st_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; st_title.add_theme_font_size_override("font_size", 24); st_box.add_child(st_title)
	var gfx_btn = Button.new(); var gfx_names = ["গ্রাফিক্স: Low (স্মুথ FPS)", "গ্রাফিক্স: Medium (ব্যালান্সড)", "গ্রাফিক্স: Ultra (সর্বোচ্চ রিয়েলিস্টিক)"]; gfx_btn.text = gfx_names[gfx_quality]
	gfx_btn.pressed.connect(func(): gfx_quality = (gfx_quality + 1) % 3; gfx_btn.text = gfx_names[gfx_quality]; _apply_graphics_quality(); _write_save()); st_box.add_child(gfx_btn)
	var mus_btn = Button.new(); mus_btn.text = "ইমোশনাল ব্যাকগ্রাউন্ড মিউজিক: চালু"
	mus_btn.pressed.connect(func(): var on = audio_mgr.toggle_music(); mus_btn.text = "ইমোশনাল ব্যাকগ্রাউন্ড মিউজিক: " + ("চালু" if on else "বন্ধ")); st_box.add_child(mus_btn)
	var sens_lbl = Label.new(); sens_lbl.text = "টাচ লুক সেন্সিটিভিটি"; st_box.add_child(sens_lbl)
	var sens_sl = HSlider.new(); sens_sl.min_value = 0.002; sens_sl.max_value = 0.009; sens_sl.step = 0.0005; sens_sl.value = look_sens; sens_sl.value_changed.connect(func(v): look_sens = v; _write_save()); st_box.add_child(sens_sl)
	var close_st = Button.new(); close_st.text = "সেভ ও বন্ধ করুন"; close_st.pressed.connect(func(): settings_panel.visible = false); st_box.add_child(close_st)
	settings_panel.add_child(st_box); ui_layer.add_child(settings_panel)

	mission_panel = ColorRect.new(); mission_panel.set_anchors_preset(Control.PRESET_FULL_RECT); mission_panel.color = Color(0.04, 0.06, 0.1, 0.94); mission_panel.visible = false
	var m_vbox = VBoxContainer.new(); m_vbox.set_anchors_preset(Control.PRESET_FULL_RECT); m_vbox.offset_left = 40; m_vbox.offset_right = -40; m_vbox.offset_top = 30; m_vbox.offset_bottom = -30
	var close_m = Button.new(); close_m.text = "বন্ধ করুন ✕"; close_m.pressed.connect(func(): mission_panel.visible = false); m_vbox.add_child(close_m)
	var scroll = ScrollContainer.new(); scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	mission_grid = GridContainer.new(); mission_grid.columns = 5; mission_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL; scroll.add_child(mission_grid); m_vbox.add_child(scroll); mission_panel.add_child(m_vbox); ui_layer.add_child(mission_panel)

	story_panel = ColorRect.new(); story_panel.set_anchors_preset(Control.PRESET_FULL_RECT); story_panel.color = Color(0.03, 0.05, 0.09, 0.95); story_panel.visible = false
	var s_hbox = HBoxContainer.new(); s_hbox.set_anchors_preset(Control.PRESET_CENTER); s_hbox.offset_left = -420; s_hbox.offset_right = 420; s_hbox.offset_top = -170; s_hbox.offset_bottom = 170; s_hbox.add_theme_constant_override("separation", 24)
	story_portrait = TextureRect.new(); story_portrait.custom_minimum_size = Vector2(240, 240); story_portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; story_portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED; s_hbox.add_child(story_portrait)
	var s_vbox = VBoxContainer.new(); s_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL; s_vbox.add_theme_constant_override("separation", 10)
	story_act_lbl = Label.new(); story_title_lbl = Label.new(); story_title_lbl.add_theme_font_size_override("font_size", 26)
	story_speaker_lbl = Label.new(); story_speaker_lbl.add_theme_color_override("font_color", Color(1.0, 0.8, 0.25))
	story_text_lbl = Label.new(); story_text_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; story_text_lbl.add_theme_font_size_override("font_size", 20)
	story_next_btn = Button.new(); story_next_btn.custom_minimum_size = Vector2(200, 48)
	story_next_btn.pressed.connect(func(): story_index += 1; if story_index < story_queue.size(): _render_story_line() else: _start_gameplay())
	s_vbox.add_child(story_act_lbl); s_vbox.add_child(story_title_lbl); s_vbox.add_child(story_speaker_lbl); s_vbox.add_child(story_text_lbl); s_vbox.add_child(story_next_btn); s_hbox.add_child(s_vbox); story_panel.add_child(s_hbox); ui_layer.add_child(story_panel)

	result_panel = ColorRect.new(); result_panel.set_anchors_preset(Control.PRESET_FULL_RECT); result_panel.color = Color(0.03, 0.05, 0.09, 0.94); result_panel.visible = false
	var r_vbox = VBoxContainer.new(); r_vbox.set_anchors_preset(Control.PRESET_CENTER); r_vbox.offset_left = -280; r_vbox.offset_right = 280; r_vbox.offset_top = -130; r_vbox.offset_bottom = 130; r_vbox.add_theme_constant_override("separation", 12)
	result_title_lbl = Label.new(); result_title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; result_title_lbl.add_theme_font_size_override("font_size", 32)
	result_desc_lbl = Label.new(); result_desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; result_desc_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	next_mission_btn = Button.new(); next_mission_btn.text = "পরবর্তী মিশন →"; next_mission_btn.pressed.connect(func(): _start_story(current_mission_idx))
	var retry_btn = Button.new(); retry_btn.text = "আবার চেষ্টা করুন"; retry_btn.pressed.connect(func(): _start_story(maxi(0, current_mission_idx - 1)))
	var home_btn = Button.new(); home_btn.text = "মেইন মেনু"; home_btn.pressed.connect(_show_menu)
	r_vbox.add_child(result_title_lbl); r_vbox.add_child(result_desc_lbl); r_vbox.add_child(next_mission_btn); r_vbox.add_child(retry_btn); r_vbox.add_child(home_btn); result_panel.add_child(r_vbox); ui_layer.add_child(result_panel)

	hud_root = Control.new(); hud_root.set_anchors_preset(Control.PRESET_FULL_RECT); hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE; hud_root.visible = false
	hud_low_hp_vignette = ColorRect.new(); hud_low_hp_vignette.set_anchors_preset(Control.PRESET_FULL_RECT); hud_low_hp_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE; hud_low_hp_vignette.color = Color(0.65, 0.0, 0.0, 0.0); hud_root.add_child(hud_low_hp_vignette)
	hud_damage_flash = ColorRect.new(); hud_damage_flash.set_anchors_preset(Control.PRESET_FULL_RECT); hud_damage_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE; hud_damage_flash.color = Color(0.85, 0.08, 0.08, 0.0); hud_root.add_child(hud_damage_flash)
	hud_scope = ColorRect.new(); hud_scope.set_anchors_preset(Control.PRESET_FULL_RECT); hud_scope.mouse_filter = Control.MOUSE_FILTER_IGNORE; hud_scope.color = Color(0, 0, 0, 0.3); hud_scope.visible = false; hud_root.add_child(hud_scope)

	var ch = ColorRect.new(); ch.set_anchors_preset(Control.PRESET_CENTER); ch.offset_left = -3; ch.offset_right = 3; ch.offset_top = -3; ch.offset_bottom = 3; ch.color = Color(1, 1, 1, 0.92); ch.mouse_filter = Control.MOUSE_FILTER_IGNORE; hud_root.add_child(ch)
	hud_hit_lbl = Label.new(); hud_hit_lbl.set_anchors_preset(Control.PRESET_CENTER); hud_hit_lbl.offset_left = -60; hud_hit_lbl.offset_right = 60; hud_hit_lbl.offset_top = -34; hud_hit_lbl.offset_bottom = -8; hud_hit_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; hud_hit_lbl.add_theme_color_override("font_color", Color(1.0, 0.25, 0.25)); hud_hit_lbl.visible = false; hud_root.add_child(hud_hit_lbl)

	var top_box = VBoxContainer.new(); top_box.position = Vector2(20, 14); hud_mission_lbl = Label.new(); hud_obj_lbl = Label.new(); hud_obj_lbl.add_theme_color_override("font_color", Color(1.0, 0.82, 0.2)); top_box.add_child(hud_mission_lbl); top_box.add_child(hud_obj_lbl); hud_root.add_child(top_box)
	var pause_btn = Button.new(); pause_btn.text = "মেনু"; pause_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT); pause_btn.offset_left = -95; pause_btn.offset_right = -18; pause_btn.offset_top = 14; pause_btn.offset_bottom = 50; pause_btn.pressed.connect(_show_menu); hud_root.add_child(pause_btn)

	var left_tact = HBoxContainer.new(); left_tact.set_anchors_preset(Control.PRESET_BOTTOM_LEFT); left_tact.offset_left = 24; left_tact.offset_right = 230; left_tact.offset_top = -224; left_tact.offset_bottom = -180; left_tact.add_theme_constant_override("separation", 6)
	var peek_l = Button.new(); peek_l.text = "↖ পিক"; peek_l.pressed.connect(func(): peek_dir = 0 if peek_dir == -1 else -1)
	var peek_r = Button.new(); peek_r.text = "পিক ↗"; peek_r.pressed.connect(func(): peek_dir = 0 if peek_dir == 1 else 1)
	var spr_btn = Button.new(); spr_btn.text = "দৌড়"; spr_btn.pressed.connect(func(): is_sprinting = not is_sprinting; spr_btn.text = "দৌড় ✓" if is_sprinting else "দৌড়")
	left_tact.add_child(peek_l); left_tact.add_child(peek_r); left_tact.add_child(spr_btn); hud_root.add_child(left_tact)

	hud_subtitle_panel = PanelContainer.new(); hud_subtitle_panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE); hud_subtitle_panel.offset_left = 240; hud_subtitle_panel.offset_right = -240; hud_subtitle_panel.offset_top = -132; hud_subtitle_panel.offset_bottom = -86; hud_subtitle_panel.visible = false
	hud_sub_lbl = Label.new(); hud_sub_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; hud_subtitle_panel.add_child(hud_sub_lbl); hud_root.add_child(hud_subtitle_panel)

	var stat_box = HBoxContainer.new(); stat_box.set_anchors_preset(Control.PRESET_CENTER_BOTTOM); stat_box.offset_left = -200; stat_box.offset_right = 200; stat_box.offset_top = -62; stat_box.offset_bottom = -16; stat_box.add_theme_constant_override("separation", 16)
	hud_hp_bar = ProgressBar.new(); hud_hp_bar.custom_minimum_size = Vector2(150, 26); hud_hp_bar.max_value = 100; hud_hp_bar.value = 100; hud_weapon_lbl = Label.new(); hud_ammo_lbl = Label.new()
	stat_box.add_child(hud_hp_bar); stat_box.add_child(hud_weapon_lbl); stat_box.add_child(hud_ammo_lbl); hud_root.add_child(stat_box)

	joy_base = ColorRect.new(); joy_base.color = Color(1, 1, 1, 0.14); joy_base.set_anchors_preset(Control.PRESET_BOTTOM_LEFT); joy_base.offset_left = 36; joy_base.offset_right = 166; joy_base.offset_top = -166; joy_base.offset_bottom = -36; joy_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joy_knob = ColorRect.new(); joy_knob.color = Color(1, 1, 1, 0.58); joy_knob.size = Vector2(46, 46); joy_knob.position = Vector2(42, 42); joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE; joy_base.add_child(joy_knob); hud_root.add_child(joy_base)

	var act_grid = GridContainer.new(); act_grid.columns = 2; act_grid.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT); act_grid.offset_left = -255; act_grid.offset_right = -18; act_grid.offset_top = -270; act_grid.offset_bottom = -18; act_grid.add_theme_constant_override("h_separation", 8); act_grid.add_theme_constant_override("v_separation", 8)
	var fire_btn = Button.new(); fire_btn.text = "গুলি"; fire_btn.custom_minimum_size = Vector2(110, 56); fire_btn.button_down.connect(func(): is_firing_held = true; _fire_weapon()); fire_btn.button_up.connect(func(): is_firing_held = false)
	var scope_btn = Button.new(); scope_btn.text = "স্কোপ"; scope_btn.custom_minimum_size = Vector2(110, 56); scope_btn.pressed.connect(func(): is_ads = not is_ads; camera.fov = 28.0 if is_ads else 72.0; hud_scope.visible = is_ads)
	var reload_btn = Button.new(); reload_btn.text = "রিলোড"; reload_btn.custom_minimum_size = Vector2(110, 48); reload_btn.pressed.connect(_reload_weapon)
	hud_grenade_btn = Button.new(); hud_grenade_btn.text = "গ্রেনেড (3)"; hud_grenade_btn.custom_minimum_size = Vector2(110, 48); hud_grenade_btn.pressed.connect(_throw_grenade)
	var sw_btn = Button.new(); sw_btn.text = "অস্ত্র বদল"; sw_btn.custom_minimum_size = Vector2(110, 48); sw_btn.pressed.connect(func(): _equip_weapon(weapon_idx + 1))
	var cr_btn = Button.new(); cr_btn.text = "বসুন"; cr_btn.custom_minimum_size = Vector2(110, 48); cr_btn.pressed.connect(func(): is_crouching = not is_crouching)
	var jump_btn = Button.new(); jump_btn.text = "জাম্প"; jump_btn.custom_minimum_size = Vector2(110, 46); jump_btn.pressed.connect(func(): if player_body.is_on_floor(): player_body.velocity.y = 7.2)
	act_grid.add_child(fire_btn); act_grid.add_child(scope_btn); act_grid.add_child(reload_btn); act_grid.add_child(hud_grenade_btn); act_grid.add_child(sw_btn); act_grid.add_child(cr_btn); act_grid.add_child(jump_btn)
	hud_root.add_child(act_grid); ui_layer.add_child(hud_root)

func _open_mission_list() -> void:
	for c in mission_grid.get_children(): c.queue_free()
	for i in range(missions.size()):
		var b = Button.new(); b.text = "মিশন %d" % missions[i]["id"]; b.custom_minimum_size = Vector2(140, 48); b.disabled = (i > unlocked_mission)
		var idx = i; b.pressed.connect(func(): _start_story(idx)); mission_grid.add_child(b)
	mission_panel.visible = true
