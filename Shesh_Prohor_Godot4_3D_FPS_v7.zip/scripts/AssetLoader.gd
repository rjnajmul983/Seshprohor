extends RefCounted
class_name AssetLoader

static var _scene_cache: Dictionary = {}

static func instantiate_glb(model_name: String, target_height: float = 0.0, add_collision: bool = false) -> Node3D:
	var path = "res://assets/models/%s.glb" % model_name
	if not ResourceLoader.exists(path):
		return null
	var packed: PackedScene = null
	if _scene_cache.has(path):
		packed = _scene_cache[path]
	else:
		var res = load(path)
		if res is PackedScene:
			packed = res
			_scene_cache[path] = packed
	if packed == null:
		return null

	var root = Node3D.new()
	var inst = packed.instantiate()
	root.add_child(inst)

	var bounds = _compute_aabb(inst)
	if bounds.size.y > 0.001 and target_height > 0.0:
		var scale_factor = target_height / bounds.size.y
		inst.scale = Vector3.ONE * scale_factor
		inst.position.y = -bounds.position.y * scale_factor

	if add_collision:
		var body = StaticBody3D.new()
		var col = CollisionShape3D.new()
		var box = BoxShape3D.new()
		var final_size = bounds.size * inst.scale.x
		if final_size.length() < 0.2:
			final_size = Vector3(2.0, maxf(1.5, target_height), 2.0)
		box.size = final_size
		col.shape = box
		col.position = Vector3(0.0, final_size.y * 0.5, 0.0)
		body.add_child(col)
		root.add_child(body)
	return root

static func _compute_aabb(node: Node) -> AABB:
	var combined = AABB()
	var has_any = false
	var stack: Array = [node]
	while stack.size() > 0:
		var curr = stack.pop_back()
		if curr is MeshInstance3D and curr.mesh != null:
			var aabb = curr.mesh.get_aabb()
			if not has_any:
				combined = aabb; has_any = true
			else:
				combined = combined.merge(aabb)
		for c in curr.get_children():
			stack.append(c)
	return combined

static func load_sky_texture(env_name: String) -> Texture2D:
	var key = "rain" if env_name == "fog" else env_name
	var hdr_path = "res://assets/sky/sky_%s.hdr" % key
	if ResourceLoader.exists(hdr_path): return load(hdr_path)
	var jpg_path = "res://assets/sky/sky_%s.jpg" % key
	if ResourceLoader.exists(jpg_path): return load(jpg_path)
	return null

static func make_pbr_material(tex_prefix: String, uv_scale: float = 1.0, wet_mode: bool = false) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	var photo_alb = "res://assets/textures/%s_photo_albedo.jpg" % tex_prefix
	var fb_alb = "res://assets/textures/%s_albedo.png" % tex_prefix
	if ResourceLoader.exists(photo_alb): m.albedo_texture = load(photo_alb)
	elif ResourceLoader.exists(fb_alb): m.albedo_texture = load(fb_alb)

	var photo_nor = "res://assets/textures/%s_photo_normal.jpg" % tex_prefix
	var fb_nor = "res://assets/textures/%s_normal.png" % tex_prefix
	if ResourceLoader.exists(photo_nor):
		m.normal_enabled = true; m.normal_texture = load(photo_nor); m.normal_scale = 1.35
	elif ResourceLoader.exists(fb_nor):
		m.normal_enabled = true; m.normal_texture = load(fb_nor); m.normal_scale = 1.35

	var photo_rgh = "res://assets/textures/%s_photo_roughness.jpg" % tex_prefix
	var fb_rgh = "res://assets/textures/%s_roughness.png" % tex_prefix
	if ResourceLoader.exists(photo_rgh): m.roughness_texture = load(photo_rgh)
	elif ResourceLoader.exists(fb_rgh): m.roughness_texture = load(fb_rgh)

	var photo_ao = "res://assets/textures/%s_photo_ao.jpg" % tex_prefix
	var fb_ao = "res://assets/textures/%s_ao.png" % tex_prefix
	if ResourceLoader.exists(photo_ao):
		m.ao_enabled = true; m.ao_texture = load(photo_ao); m.ao_light_affect = 0.78
	elif ResourceLoader.exists(fb_ao):
		m.ao_enabled = true; m.ao_texture = load(fb_ao); m.ao_light_affect = 0.78

	m.roughness = 0.20 if wet_mode else 0.90
	m.metallic = 0.18 if wet_mode else 0.0
	m.uv1_scale = Vector3(uv_scale, uv_scale, uv_scale)
	return m
