extends Node
class_name AudioManager

var sfx_player: AudioStreamPlayer
var footstep_player: AudioStreamPlayer
var heartbeat_player: AudioStreamPlayer
var music_player: AudioStreamPlayer
var music_on: bool = true
var wav_cache: Dictionary = {}

func _ready() -> void:
	sfx_player = AudioStreamPlayer.new(); add_child(sfx_player)
	footstep_player = AudioStreamPlayer.new(); footstep_player.volume_db = -8.0; add_child(footstep_player)
	heartbeat_player = AudioStreamPlayer.new(); heartbeat_player.volume_db = -4.0; add_child(heartbeat_player)
	music_player = AudioStreamPlayer.new(); music_player.volume_db = -14.0; add_child(music_player)

	var durs = {"rifle": 0.16, "sniper": 0.32, "shotgun": 0.28, "pistol": 0.10, "boom": 0.85, "thunder": 1.4, "hit": 0.07, "headshot": 0.12, "reload": 0.24, "step_grass": 0.09, "step_asphalt": 0.07, "heartbeat": 0.45}
	for k in durs.keys(): wav_cache[k] = _make_wav(durs[k], k)
	wav_cache["music"] = _make_ambient_music()
	music_player.stream = wav_cache["music"]
	music_player.finished.connect(func(): if music_on: music_player.play())
	music_player.play()

func toggle_music() -> bool:
	music_on = not music_on
	if music_on: music_player.play()
	else: music_player.stop()
	return music_on

func _make_ambient_music() -> AudioStreamWAV:
	var mix_rate = 16000; var frames = mix_rate * 8; var data = PackedByteArray(); data.resize(frames * 2)
	var chords = [220.0, 174.61, 261.63, 196.0]
	for i in range(frames):
		var t = float(i) / float(mix_rate); var f = chords[int(t / 2.0) % 4]
		var env = sin(fmod(t, 2.0) / 2.0 * PI) * 0.22
		var s = (sin(t * f * TAU) * 0.6 + sin(t * f * 1.5 * TAU) * 0.25 + sin(t * f * 0.5 * TAU) * 0.4) * env
		var v = int(clampf(s, -1.0, 1.0) * 32767.0); data[i * 2] = v & 0xFF; data[i * 2 + 1] = (v >> 8) & 0xFF
	var wav = AudioStreamWAV.new(); wav.format = AudioStreamWAV.FORMAT_16_BITS; wav.mix_rate = mix_rate; wav.data = data
	return wav

func _make_wav(duration: float, mode: String) -> AudioStreamWAV:
	var mix_rate = 22050; var frames = int(mix_rate * duration); var data = PackedByteArray(); data.resize(frames * 2)
	var rng = RandomNumberGenerator.new(); rng.seed = mode.hash()
	for i in range(frames):
		var t = float(i) / float(mix_rate); var sample: float = 0.0
		if mode == "rifle": sample = (rng.randf_range(-1.0, 1.0) * 0.78 + sin(t * 820.0) * 0.25) * exp(-t * 16.0)
		elif mode == "sniper": sample = (rng.randf_range(-1.0, 1.0) * 0.85 + sin(t * 420.0) * 0.4) * exp(-t * 9.0)
		elif mode == "shotgun": sample = (rng.randf_range(-1.0, 1.0) * 0.9 + sin(t * 220.0) * 0.5) * exp(-t * 10.5)
		elif mode == "pistol": sample = (rng.randf_range(-1.0, 1.0) * 0.65 + sin(t * 1350.0) * 0.25) * exp(-t * 24.0)
		elif mode == "boom": sample = (rng.randf_range(-1.0, 1.0) * 0.65 + sin(t * 110.0) * 0.55) * exp(-t * 3.4)
		elif mode == "thunder": sample = (rng.randf_range(-1.0, 1.0) * 0.5 + sin(t * 75.0) * 0.45) * exp(-t * 1.8) * (0.6 + 0.4 * sin(t * 14.0))
		elif mode == "hit": sample = sin(t * 5200.0) * exp(-t * 35.0) * 0.55
		elif mode == "headshot": sample = (sin(t * 7400.0) + sin(t * 3700.0) * 0.5) * exp(-t * 22.0) * 0.65
		elif mode == "reload": sample = (exp(-absf(t - 0.04) * 90.0) * sin(t * 3200.0) + exp(-absf(t - 0.16) * 80.0) * sin(t * 4600.0)) * 0.5
		elif mode == "step_grass": sample = rng.randf_range(-1.0, 1.0) * exp(-t * 28.0) * 0.35
		elif mode == "step_asphalt": sample = (rng.randf_range(-1.0, 1.0) * 0.4 + sin(t * 620.0) * 0.5) * exp(-t * 42.0) * 0.45
		elif mode == "heartbeat": sample = (exp(-absf(t - 0.08) * 38.0) * sin(t * 260.0) + exp(-absf(t - 0.24) * 38.0) * sin(t * 220.0) * 0.75) * 0.85
		var v = int(clampf(sample, -1.0, 1.0) * 32767.0); data[i * 2] = v & 0xFF; data[i * 2 + 1] = (v >> 8) & 0xFF
	var wav = AudioStreamWAV.new(); wav.format = AudioStreamWAV.FORMAT_16_BITS; wav.mix_rate = mix_rate; wav.data = data
	return wav

func play_2d(key: String) -> void:
	if wav_cache.has(key): sfx_player.stream = wav_cache[key]; sfx_player.play()

func play_footstep(is_asphalt: bool) -> void:
	if not footstep_player.playing:
		footstep_player.stream = wav_cache["step_asphalt" if is_asphalt else "step_grass"]; footstep_player.play()

func play_heartbeat() -> void:
	if not heartbeat_player.playing: heartbeat_player.stream = wav_cache["heartbeat"]; heartbeat_player.play()

func play_3d(world: Node3D, pos: Vector3, key: String, max_dist: float = 55.0) -> void:
	if not wav_cache.has(key): return
	var p = AudioStreamPlayer3D.new(); p.stream = wav_cache[key]; p.max_distance = max_dist; p.unit_size = 8.0; p.position = pos
	world.add_child(p); p.play(); p.finished.connect(func(): p.queue_free())
