window.TEX = (function() {
    function makeCanvasTex(size, drawFn, repeat = 1) {
        const c = document.createElement('canvas');
        c.width = c.height = size;
        const ctx = c.getContext('2d');
        drawFn(ctx, size);
        const tex = new THREE.CanvasTexture(c);
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        tex.repeat.set(repeat, repeat);
        return tex;
    }

    const grass = makeCanvasTex(256, (ctx, s) => {
        ctx.fillStyle = '#2d4a22';
        ctx.fillRect(0, 0, s, s);
        for (let i = 0; i < 3500; i++) {
            ctx.fillStyle = Math.random() > 0.5 ? '#3b5e2b' : '#1e3516';
            ctx.fillRect(Math.random() * s, Math.random() * s, 2, 6);
        }
    }, 28);

    const asphalt = makeCanvasTex(256, (ctx, s) => {
        ctx.fillStyle = '#2b2f36';
        ctx.fillRect(0, 0, s, s);
        for (let i = 0; i < 2000; i++) {
            const v = 30 + Math.random() * 35;
            ctx.fillStyle = `rgb(${v},${v},${v})`;
            ctx.fillRect(Math.random() * s, Math.random() * s, 2, 2);
        }
        ctx.fillStyle = '#d4af37';
        ctx.fillRect(s * 0.48, 0, s * 0.04, s * 0.5);
    }, 14);

    const brick = makeCanvasTex(256, (ctx, s) => {
        ctx.fillStyle = '#5c4d42';
        ctx.fillRect(0, 0, s, s);
        ctx.fillStyle = '#7c4a3a';
        const rows = 8, cols = 4;
        const bh = s / rows, bw = s / cols;
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const offset = (r % 2) * (bw / 2);
                ctx.fillStyle = (r + c) % 2 === 0 ? '#7a4938' : '#6c3f30';
                ctx.fillRect((c * bw + offset) % s + 2, r * bh + 2, bw - 4, bh - 4);
            }
        }
    }, 3);

    const concrete = makeCanvasTex(256, (ctx, s) => {
        ctx.fillStyle = '#64748b';
        ctx.fillRect(0, 0, s, s);
        for (let i = 0; i < 1500; i++) {
            ctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.08)';
            ctx.fillRect(Math.random() * s, Math.random() * s, 4, 4);
        }
        // Windows
        ctx.fillStyle = '#1e293b';
        for (let y = 24; y < s - 30; y += 60) {
            for (let x = 24; x < s - 30; x += 60) {
                ctx.fillRect(x, y, 32, 38);
            }
        }
    }, 2);

    const crate = makeCanvasTex(128, (ctx, s) => {
        ctx.fillStyle = '#785233';
        ctx.fillRect(0, 0, s, s);
        ctx.strokeStyle = '#4a301a';
        ctx.lineWidth = 8;
        ctx.strokeRect(4, 4, s - 8, s - 8);
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(s, s); ctx.stroke();
    }, 1);

    return { grass, asphalt, brick, concrete, crate };
})();
