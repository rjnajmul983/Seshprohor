const WEAPONS = [
    { id: 'rifle', name: 'AK-47 রাইফেল', dmg: 34, mag: 30, reserve: 150, rate: 130, spread: 0.015 },
    { id: 'sniper', name: 'স্নাইপার রাইফেল', dmg: 115, mag: 5, reserve: 30, rate: 850, spread: 0.002 },
    { id: 'shotgun', name: 'শটগান', dmg: 78, mag: 8, reserve: 40, rate: 620, spread: 0.05 },
    { id: 'pistol', name: '৯মিমি পিস্তল', dmg: 26, mag: 15, reserve: 90, rate: 260, spread: 0.01 }
];

let scene, camera, renderer, clock;
let enemies = [], ally = null, grenades = [], bullets = [], colliders = [];
let rainSystem = null, weaponMesh = null, muzzleLight = null;
let currentMissionIdx = parseInt(localStorage.getItem('sp_mission') || '0', 10);
let unlockedMission = parseInt(localStorage.getItem('sp_unlocked') || '0', 10);
let gameState = 'menu';

let player = {
    hp: 100, maxHp: 100, yaw: 0, pitch: 0, crouch: false, ads: false,
    weaponIdx: 0, ammo: 30, reserve: 150, grenades: 3, lastShot: 0, reloading: false, bob: 0
};
let joyVec = { x: 0, y: 0 }, keys = {};
let storyQueue = [], storyIndex = 0, midTriggered = false, totalMissionEnemies = 0;

const el = id => document.getElementById(id);

function initThree() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.1, 320);
    renderer = new THREE.WebGLRenderer({ canvas: el('game-canvas'), antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    clock = new THREE.Clock();

    buildWeaponViewmodel();
    scene.add(camera);

    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
}

// First-person realistic hand + weapon viewmodel
function buildWeaponViewmodel() {
    if (weaponMesh) camera.remove(weaponMesh);
    weaponMesh = new THREE.Group();

    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.75, roughness: 0.3 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x5c3a21, roughness: 0.8 });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xc68642, roughness: 0.7 });
    const sleeveMat = new THREE.MeshStandardMaterial({ color: 0x2d3a2d, roughness: 0.9 });

    // Gun receiver & barrel
    const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.065, 0.58), bodyMat);
    barrel.position.set(0.24, -0.22, -0.46);
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.1, 0.22), woodMat);
    stock.position.set(0.24, -0.25, -0.18);
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.16, 0.07), bodyMat);
    mag.position.set(0.24, -0.32, -0.38);
    mag.rotation.x = 0.2;

    // Hands & Sleeves
    const rightHand = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.12), skinMat);
    rightHand.position.set(0.24, -0.28, -0.26);
    const rightArm = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.28), sleeveMat);
    rightArm.position.set(0.3, -0.34, -0.1);
    const leftHand = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.07, 0.12), skinMat);
    leftHand.position.set(0.18, -0.26, -0.48);

    weaponMesh.add(barrel, stock, mag, rightHand, rightArm, leftHand);

    muzzleLight = new THREE.PointLight(0xffaa33, 0, 8);
    muzzleLight.position.set(0.24, -0.2, -0.82);
    weaponMesh.add(muzzleLight);

    camera.add(weaponMesh);
}

function clearScene() {
    for (let i = scene.children.length - 1; i >= 0; i--) {
        if (scene.children[i] !== camera) scene.remove(scene.children[i]);
    }
    enemies = [];
    ally = null;
    grenades = [];
    bullets = [];
    colliders = [];
    rainSystem = null;
}

function addCollider(x, z, halfW, halfD) {
    colliders.push({ minX: x - halfW, maxX: x + halfW, minZ: z - halfD, maxZ: z + halfD });
}

function isBlocked(x, z, radius = 0.7) {
    if (Math.abs(x) > 95 || Math.abs(z) > 95) return true;
    for (const c of colliders) {
        if (x + radius > c.minX && x - radius < c.maxX && z + radius > c.minZ && z - radius < c.maxZ) {
            return true;
        }
    }
    return false;
}

function buildEnvironment(env, mapType) {
    clearScene();
    const envColors = {
        day: { sky: 0x87ceeb, fog: 0x9ec5d8, light: 0xffffff, amb: 0.7 },
        sunset: { sky: 0xd97757, fog: 0xb4533c, light: 0xffb380, amb: 0.55 },
        night: { sky: 0x0b1120, fog: 0x0f172a, light: 0x64748b, amb: 0.35 },
        rain: { sky: 0x334155, fog: 0x475569, light: 0x94a3b8, amb: 0.48 },
        fog: { sky: 0x94a3b8, fog: 0x94a3b8, light: 0xe2e8f0, amb: 0.62 }
    };
    const cfg = envColors[env] || envColors.day;
    scene.background = new THREE.Color(cfg.sky);
    scene.fog = new THREE.FogExp2(cfg.fog, env === 'fog' ? 0.032 : 0.013);

    scene.add(new THREE.AmbientLight(0xffffff, cfg.amb));
    const dir = new THREE.DirectionalLight(cfg.light, 1.05);
    dir.position.set(35, 65, 25);
    dir.castShadow = true;
    scene.add(dir);

    // Textured Ground
    const groundTex = (mapType === 'city' || mapType === 'bridge') ? window.TEX.asphalt : window.TEX.grass;
    const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(210, 210),
        new THREE.MeshStandardMaterial({ map: groundTex, roughness: 0.92 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    const wallMat = new THREE.MeshStandardMaterial({
        map: mapType === 'village' ? window.TEX.brick : window.TEX.concrete, roughness: 0.85
    });
    const crateMat = new THREE.MeshStandardMaterial({ map: window.TEX.crate, roughness: 0.8 });
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3219 });
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x1e4620 });
    const carMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, metalness: 0.45, roughness: 0.4 });

    // Distinct Map Layouts with Colliders
    const buildingCount = mapType === 'forest' ? 6 : 16;
    for (let i = 0; i < buildingCount; i++) {
        const angle = (i / buildingCount) * Math.PI * 2;
        const dist = mapType === 'bridge' ? (16 + (i % 2) * 14) : (22 + (i % 3) * 18);
        const w = mapType === 'city' ? 9 : 7;
        const h = mapType === 'city' ? (10 + (i % 4) * 5) : (4.5 + (i % 3) * 2.5);
        const bx = Math.cos(angle) * dist, bz = Math.sin(angle) * dist;
        const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, w), wallMat);
        b.position.set(bx, h / 2, bz);
        b.castShadow = true;
        b.receiveShadow = true;
        scene.add(b);
        addCollider(bx, bz, w / 2, w / 2);
    }

    // Tactical Cover Crates
    for (let i = 0; i < 14; i++) {
        const cx = (Math.random() - 0.5) * 65;
        const cz = (Math.random() - 0.5) * 65;
        if (Math.hypot(cx, cz) < 8 || isBlocked(cx, cz, 2)) continue;
        const crate = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.5, 2.2), crateMat);
        crate.position.set(cx, 0.75, cz);
        crate.castShadow = true;
        scene.add(crate);
        addCollider(cx, cz, 1.1, 1.1);
    }

    // Trees
    const treeCount = mapType === 'forest' ? 55 : 22;
    for (let i = 0; i < treeCount; i++) {
        const tx = (Math.random() - 0.5) * 140;
        const tz = (Math.random() - 0.5) * 140;
        if (Math.hypot(tx, tz) < 10 || isBlocked(tx, tz, 2)) continue;
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.48, 3.2, 7), trunkMat);
        trunk.position.set(tx, 1.6, tz);
        const leaves = new THREE.Mesh(new THREE.ConeGeometry(2.3, 4.8, 7), leafMat);
        leaves.position.set(tx, 4.8, tz);
        scene.add(trunk, leaves);
        addCollider(tx, tz, 0.6, 0.6);
    }

    // Vehicles
    for (let i = 0; i < 5; i++) {
        const vx = (i - 2) * 14, vz = -16 - (i % 2) * 14;
        if (isBlocked(vx, vz, 3)) continue;
        const car = new THREE.Mesh(new THREE.BoxGeometry(2.3, 1.35, 4.5), carMat);
        car.position.set(vx, 0.68, vz);
        car.castShadow = true;
        scene.add(car);
        addCollider(vx, vz, 1.2, 2.3);
    }

    if (env === 'rain') {
        const rainGeo = new THREE.BufferGeometry();
        const pos = [];
        for (let i = 0; i < 950; i++) {
            pos.push((Math.random() - 0.5) * 85, Math.random() * 35, (Math.random() - 0.5) * 85);
        }
        rainGeo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
        rainSystem = new THREE.Points(rainGeo, new THREE.PointsMaterial({ color: 0xcbd5e1, size: 0.18 }));
        scene.add(rainSystem);
    }
}

// Detailed Humanoid with Helmet, Vest, Rifle & Limb Animation
function createHumanoid(isAlly = false) {
    const g = new THREE.Group();
    const skin = new THREE.MeshStandardMaterial({ color: 0xd2a679 });
    const uniform = new THREE.MeshStandardMaterial({ color: isAlly ? 0x1d4ed8 : 0x3f3f46 });
    const vest = new THREE.MeshStandardMaterial({ color: isAlly ? 0x1e3a8a : 0x18181b });
    const pants = new THREE.MeshStandardMaterial({ color: 0x1f2937 });
    const gunMat = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.7 });

    const head = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.36, 0.36), skin);
    head.position.y = 1.66;
    const helmet = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.2, 0.42), vest);
    helmet.position.y = 1.82;
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.72, 0.34), uniform);
    torso.position.y = 1.1;
    const armor = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.46, 0.38), vest);
    armor.position.y = 1.14;

    const legL = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.74, 0.22), pants);
    legL.position.set(-0.15, 0.37, 0);
    const legR = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.74, 0.22), pants);
    legR.position.set(0.15, 0.37, 0);

    const armL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.58, 0.18), uniform);
    armL.position.set(-0.38, 1.12, 0.1);
    const armR = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.58, 0.18), uniform);
    armR.position.set(0.38, 1.12, 0.1);
    armR.rotation.x = -Math.PI / 3;

    const rifle = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.1, 0.75), gunMat);
    rifle.position.set(0.35, 1.15, 0.45);

    g.add(head, helmet, torso, armor, legL, legR, armL, armR, rifle);
    g.userData = { legL, legR };
    return g;
}

function spawnUnits(mission) {
    // Spawn Story Ally alongside player
    const allyMesh = createHumanoid(true);
    allyMesh.position.set(3, 0, -2);
    scene.add(allyMesh);
    ally = { mesh: allyMesh, name: mission.allyName, lastShot: 0, walkPhase: 0 };
    el('hud-ally-status').textContent = `সহযোদ্ধা: ${mission.allyName} (সক্রিয়)`;

    totalMissionEnemies = mission.enemies;
    for (let i = 0; i < mission.enemies; i++) {
        const mesh = createHumanoid(false);
        let ex, ez, tries = 0;
        do {
            const angle = Math.random() * Math.PI * 2;
            const dist = 24 + Math.random() * 44;
            ex = Math.cos(angle) * dist;
            ez = Math.sin(angle) * dist;
            tries++;
        } while (isBlocked(ex, ez, 1.2) && tries < 20);

        mesh.position.set(ex, 0, ez);
        scene.add(mesh);
        enemies.push({
            mesh, hp: mission.enemyHp, speed: mission.enemySpeed,
            lastAttack: 0, walkPhase: Math.random() * 6, strafeDir: Math.random() > 0.5 ? 1 : -1
        });
    }
}

function spawnTracer(fromPos, toPos, color = 0xffcc33) {
    const mat = new THREE.LineBasicMaterial({ color });
    const geo = new THREE.BufferGeometry().setFromPoints([fromPos, toPos]);
    const line = new THREE.Line(geo, mat);
    scene.add(line);
    bullets.push({ mesh: line, life: 0.08 });
}

function startStory(idx) {
    currentMissionIdx = idx;
    const m = window.MISSIONS[idx];
    gameState = 'story';
    el('menu-screen').classList.add('hidden');
    el('mission-modal').classList.add('hidden');
    el('result-screen').classList.add('hidden');
    el('hud').classList.add('hidden');
    el('story-screen').classList.remove('hidden');

    el('story-act').textContent = m.act;
    el('story-title').textContent = `মিশন ${m.id}: ${m.title}`;
    el('story-objective').textContent = `লক্ষ্য: ${m.objective}`;
    storyQueue = m.intro;
    storyIndex = 0;
    renderStoryLine();
}

function renderStoryLine() {
    const line = storyQueue[storyIndex];
    el('story-speaker').textContent = line.s + ":";
    el('story-text').textContent = line.t;
    el('btn-story-next').textContent = storyIndex === storyQueue.length - 1 ? "যুদ্ধ শুরু করুন →" : "পরবর্তী →";
}

function startMissionGameplay() {
    const m = window.MISSIONS[currentMissionIdx];
    el('story-screen').classList.add('hidden');
    el('hud').classList.remove('hidden');
    gameState = 'playing';
    midTriggered = false;

    player.hp = 100;
    player.yaw = 0;
    player.pitch = 0;
    player.grenades = 3;
    player.weaponIdx = 0;
    equipWeapon(0);

    camera.position.set(0, 1.7, 0);
    buildEnvironment(m.env, m.mapType);
    spawnUnits(m);

    el('hud-mission-name').textContent = `মিশন ${m.id}: ${m.title}`;
    updateHUD();
    showSubtitle(m.intro[0].s, m.intro[0].t, 4000);
}

function equipWeapon(idx) {
    player.weaponIdx = idx;
    const w = WEAPONS[idx];
    player.ammo = w.mag;
    player.reserve = w.reserve;
    updateHUD();
}

function updateHUD() {
    const w = WEAPONS[player.weaponIdx];
    el('hp-val').textContent = Math.max(0, Math.round(player.hp));
    el('hp-bar').style.width = Math.max(0, player.hp) + '%';
    el('weapon-name').textContent = w.name;
    el('ammo-display').textContent = `${player.ammo} / ${player.reserve}`;
    el('grenade-count').textContent = player.grenades;
    el('hud-objective').textContent = `শত্রু বাকি: ${enemies.length}`;
}

function showSubtitle(speaker, text, ms = 4500) {
    el('sub-speaker').textContent = speaker + ":";
    el('sub-text').textContent = text;
    el('subtitle-bar').classList.remove('hidden');
    clearTimeout(window._subTimer);
    window._subTimer = setTimeout(() => el('subtitle-bar').classList.add('hidden'), ms);
}

function fireWeapon() {
    if (gameState !== 'playing' || player.reloading) return;
    const w = WEAPONS[player.weaponIdx];
    const now = performance.now();
    if (now - player.lastShot < w.rate) return;
    if (player.ammo <= 0) { reloadWeapon(); return; }

    player.lastShot = now;
    player.ammo--;
    window.SFX.playGunshot(w.id);

    weaponMesh.position.z = 0.08;
    muzzleLight.intensity = 4.5;
    setTimeout(() => { weaponMesh.position.z = 0; muzzleLight.intensity = 0; }, 65);

    const ray = new THREE.Raycaster();
    ray.setFromCamera(new THREE.Vector2((Math.random() - 0.5) * w.spread, (Math.random() - 0.5) * w.spread), camera);

    const enemyMeshes = enemies.map(e => e.mesh);
    const hits = ray.intersectObjects(enemyMeshes, true);
    if (hits.length > 0) {
        let obj = hits[0].object;
        while (obj.parent && obj.parent !== scene) obj = obj.parent;
        const target = enemies.find(e => e.mesh === obj);
        if (target) {
            target.hp -= w.dmg;
            window.SFX.playHit();
            el('hitmarker').classList.remove('hidden');
            setTimeout(() => el('hitmarker').classList.add('hidden'), 120);
            if (target.hp <= 0) killEnemy(target);
        }
    }
    updateHUD();
}

function killEnemy(target) {
    scene.remove(target.mesh);
    enemies = enemies.filter(e => e !== target);
    const m = window.MISSIONS[currentMissionIdx];

    if (!midTriggered && enemies.length <= Math.floor(totalMissionEnemies / 2)) {
        midTriggered = true;
        showSubtitle(m.mid.s, m.mid.t, 5000);
    }
    if (enemies.length === 0) missionSuccess();
    updateHUD();
}

function reloadWeapon() {
    if (player.reloading) return;
    const w = WEAPONS[player.weaponIdx];
    if (player.ammo === w.mag || player.reserve <= 0) return;
    player.reloading = true;
    window.SFX.playReload();
    weaponMesh.rotation.x = -0.45;
    setTimeout(() => {
        const need = w.mag - player.ammo;
        const take = Math.min(need, player.reserve);
        player.ammo += take;
        player.reserve -= take;
        player.reloading = false;
        weaponMesh.rotation.x = 0;
        updateHUD();
    }, 950);
}

function throwGrenade() {
    if (gameState !== 'playing' || player.grenades <= 0) return;
    player.grenades--;
    updateHUD();
    const gMesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.14, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0x365314 })
    );
    gMesh.position.copy(camera.position);
    const dir = new THREE.Vector3(0, 0.25, -1).applyQuaternion(camera.quaternion).normalize();
    scene.add(gMesh);
    grenades.push({ mesh: gMesh, vel: dir.multiplyScalar(16), timer: 1.6 });
}

function missionSuccess() {
    gameState = 'result';
    const m = window.MISSIONS[currentMissionIdx];
    if (currentMissionIdx + 1 > unlockedMission && currentMissionIdx + 1 < 50) {
        unlockedMission = currentMissionIdx + 1;
        localStorage.setItem('sp_unlocked', unlockedMission);
    }
    localStorage.setItem('sp_mission', Math.min(49, currentMissionIdx + 1));

    el('checkpoint-toast').style.opacity = 1;
    setTimeout(() => el('checkpoint-toast').style.opacity = 0, 2200);

    el('hud').classList.add('hidden');
    el('result-screen').classList.remove('hidden');
    el('result-title').textContent = `মিশন ${m.id} সম্পন্ন!`;
    el('result-desc').textContent = m.outro;
    el('btn-next-mission').classList.toggle('hidden', currentMissionIdx >= 49);
}

function missionFailed() {
    gameState = 'result';
    el('hud').classList.add('hidden');
    el('result-screen').classList.remove('hidden');
    el('result-title').textContent = "আপনি শহীদ হয়েছেন";
    el('result-desc').textContent = "হাল ছাড়বেন না—চেকপয়েন্ট থেকে আবার লড়াই শুরু করুন।";
    el('btn-next-mission').classList.add('hidden');
}

function animate() {
    requestAnimationFrame(animate);
    const dt = Math.min(0.05, clock.getDelta());

    if (gameState === 'playing') {
        // Player Movement with Collision
        let moveX = joyVec.x + (keys['KeyD'] ? 1 : 0) - (keys['KeyA'] ? 1 : 0);
        let moveZ = joyVec.y + (keys['KeyS'] ? 1 : 0) - (keys['KeyW'] ? 1 : 0);
        const speed = player.crouch ? 3.5 : 6.8;

        const forward = new THREE.Vector3(-Math.sin(player.yaw), 0, -Math.cos(player.yaw));
        const right = new THREE.Vector3(Math.cos(player.yaw), 0, -Math.sin(player.yaw));
        const dx = (forward.x * -moveZ + right.x * moveX) * speed * dt;
        const dz = (forward.z * -moveZ + right.z * moveX) * speed * dt;

        if (!isBlocked(camera.position.x + dx, camera.position.z)) camera.position.x += dx;
        if (!isBlocked(camera.position.x, camera.position.z + dz)) camera.position.z += dz;

        // Weapon walk bob
        if (Math.hypot(moveX, moveZ) > 0.1) {
            player.bob += dt * 10;
            weaponMesh.position.y = Math.sin(player.bob) * 0.015;
        }
        camera.position.y = player.crouch ? 1.1 : 1.7;
        camera.rotation.order = 'YXZ';
        camera.rotation.y = player.yaw;
        camera.rotation.x = player.pitch;

        if (rainSystem) {
            rainSystem.position.y -= 18 * dt;
            if (rainSystem.position.y < -10) rainSystem.position.y = 10;
        }

        const now = performance.now();

        // Ally AI: Follows player & shoots nearest enemy
        if (ally && enemies.length > 0) {
            const toPlayerX = camera.position.x - ally.mesh.position.x + 2.5;
            const toPlayerZ = camera.position.z - ally.mesh.position.z + 2.5;
            const pDist = Math.hypot(toPlayerX, toPlayerZ);
            if (pDist > 4) {
                ally.mesh.position.x += (toPlayerX / pDist) * 4.5 * dt;
                ally.mesh.position.z += (toPlayerZ / pDist) * 4.5 * dt;
                ally.walkPhase += dt * 8;
                ally.mesh.userData.legL.rotation.x = Math.sin(ally.walkPhase) * 0.45;
                ally.mesh.userData.legR.rotation.x = -Math.sin(ally.walkPhase) * 0.45;
            }
            const nearest = enemies[0];
            ally.mesh.lookAt(nearest.mesh.position.x, 0, nearest.mesh.position.z);
            if (now - ally.lastShot > 1800 && ally.mesh.position.distanceTo(nearest.mesh.position) < 35) {
                ally.lastShot = now;
                spawnTracer(
                    ally.mesh.position.clone().add(new THREE.Vector3(0, 1.3, 0)),
                    nearest.mesh.position.clone().add(new THREE.Vector3(0, 1.2, 0)),
                    0x38bdf8
                );
                nearest.hp -= 18;
                if (nearest.hp <= 0) killEnemy(nearest);
            }
        }

        // Enemy AI: Ranged Shooting + Strafe + Collision
        enemies.forEach(e => {
            const ex = camera.position.x - e.mesh.position.x;
            const ez = camera.position.z - e.mesh.position.z;
            const dist = Math.hypot(ex, ez);
            e.mesh.lookAt(camera.position.x, 0, camera.position.z);

            if (dist > 14) {
                const nx = e.mesh.position.x + (ex / dist) * e.speed * dt;
                const nz = e.mesh.position.z + (ez / dist) * e.speed * dt;
                if (!isBlocked(nx, nz, 0.7)) {
                    e.mesh.position.x = nx;
                    e.mesh.position.z = nz;
                }
                e.walkPhase += dt * 8;
                e.mesh.userData.legL.rotation.x = Math.sin(e.walkPhase) * 0.5;
                e.mesh.userData.legR.rotation.x = -Math.sin(e.walkPhase) * 0.5;
            }
            // Ranged fire when within 28m
            if (dist < 28 && now - e.lastAttack > 1700) {
                e.lastAttack = now;
                window.SFX.playEnemyShot();
                spawnTracer(
                    e.mesh.position.clone().add(new THREE.Vector3(0, 1.3, 0)),
                    camera.position.clone().add(new THREE.Vector3((Math.random()-0.5)*1.2, -0.3, (Math.random()-0.5)*1.2)),
                    0xff5533
                );
                if (Math.random() < 0.55) {
                    player.hp -= 7;
                    el('damage-vignette').style.boxShadow = 'inset 0 0 90px rgba(220,38,38,0.75)';
                    setTimeout(() => el('damage-vignette').style.boxShadow = 'inset 0 0 90px rgba(220,38,38,0)', 220);
                    updateHUD();
                    if (player.hp <= 0) missionFailed();
                }
            }
        });

        // Update Bullets
        for (let i = bullets.length - 1; i >= 0; i--) {
            bullets[i].life -= dt;
            if (bullets[i].life <= 0) {
                scene.remove(bullets[i].mesh);
                bullets.splice(i, 1);
            }
        }

        // Update Grenades
        for (let i = grenades.length - 1; i >= 0; i--) {
            const g = grenades[i];
            g.vel.y -= 24 * dt;
            g.mesh.position.addScaledVector(g.vel, dt);
            if (g.mesh.position.y < 0.2) { g.mesh.position.y = 0.2; g.vel.y *= -0.4; }
            g.timer -= dt;
            if (g.timer <= 0) {
                window.SFX.playExplosion();
                const pos = g.mesh.position.clone();
                scene.remove(g.mesh);
                grenades.splice(i, 1);
                [...enemies].forEach(e => {
                    if (e.mesh.position.distanceTo(pos) < 11) killEnemy(e);
                });
            }
        }
    }
    renderer.render(scene, camera);
}

function bindControls() {
    el('btn-continue').textContent = `মিশন শুরু করুন (মিশন ${currentMissionIdx + 1})`;
    el('btn-continue').onclick = () => { window.SFX.init(); startStory(currentMissionIdx); };
    el('btn-missions').onclick = () => {
        const grid = el('mission-grid');
        grid.innerHTML = '';
        window.MISSIONS.forEach((m, i) => {
            const card = document.createElement('div');
            card.className = 'm-card' + (i > unlockedMission ? ' locked' : '');
            card.innerHTML = `<div class="m-num">মিশন ${m.id}</div><div class="m-name">${m.title}</div>`;
            card.onclick = () => { window.SFX.init(); startStory(i); };
            grid.appendChild(card);
        });
        el('mission-modal').classList.remove('hidden');
    };
    el('btn-close-modal').onclick = () => el('mission-modal').classList.add('hidden');
    el('btn-story-next').onclick = () => {
        storyIndex++;
        if (storyIndex < storyQueue.length) renderStoryLine();
        else startMissionGameplay();
    };
    el('btn-next-mission').onclick = () => startStory(Math.min(49, currentMissionIdx + 1));
    el('btn-retry').onclick = () => startStory(currentMissionIdx);
    el('btn-home').onclick = () => {
        gameState = 'menu';
        el('result-screen').classList.add('hidden');
        el('hud').classList.add('hidden');
        el('menu-screen').classList.remove('hidden');
    };
    el('btn-pause').onclick = el('btn-home').onclick;
    el('btn-music').onclick = () => {
        const on = window.SFX.toggleMusic();
        el('btn-music').textContent = on ? 'মিউজিক: চালু' : 'মিউজিক: বন্ধ';
    };

    let fireInterval = null;
    el('btn-fire').addEventListener('touchstart', e => { e.preventDefault(); fireWeapon(); fireInterval = setInterval(fireWeapon, 140); });
    el('btn-fire').addEventListener('touchend', () => clearInterval(fireInterval));
    el('btn-fire').addEventListener('mousedown', fireWeapon);

    el('btn-reload').onclick = reloadWeapon;
    el('btn-grenade').onclick = throwGrenade;
    el('btn-weapon').onclick = () => equipWeapon((player.weaponIdx + 1) % WEAPONS.length);
    el('btn-crouch').onclick = () => { player.crouch = !player.crouch; };
    el('btn-ads').onclick = () => {
        player.ads = !player.ads;
        camera.fov = player.ads ? 32 : 72;
        camera.updateProjectionMatrix();
        el('scope-overlay').classList.toggle('hidden', !player.ads);
    };

    // Virtual Joystick
    const jZone = el('joystick-zone'), knob = el('joystick-knob');
    let jId = null, jCenter = { x: 0, y: 0 };
    jZone.addEventListener('touchstart', e => {
        const t = e.changedTouches[0];
        jId = t.identifier;
        const rect = jZone.getBoundingClientRect();
        jCenter = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    });
    jZone.addEventListener('touchmove', e => {
        for (const t of e.changedTouches) {
            if (t.identifier === jId) {
                const dx = t.clientX - jCenter.x, dy = t.clientY - jCenter.y;
                const dist = Math.min(36, Math.hypot(dx, dy));
                const ang = Math.atan2(dy, dx);
                knob.style.transform = `translate(${Math.cos(ang)*dist}px, ${Math.sin(ang)*dist}px)`;
                joyVec.x = (Math.cos(ang) * dist) / 36;
                joyVec.y = (Math.sin(ang) * dist) / 36;
            }
        }
    });
    const resetJoy = () => { jId = null; joyVec = { x: 0, y: 0 }; knob.style.transform = 'translate(0,0)'; };
    jZone.addEventListener('touchend', resetJoy);
    jZone.addEventListener('touchcancel', resetJoy);

    // Look Zone
    const lZone = el('look-zone');
    let lId = null, lastLook = { x: 0, y: 0 };
    lZone.addEventListener('touchstart', e => {
        const t = e.changedTouches[0];
        lId = t.identifier;
        lastLook = { x: t.clientX, y: t.clientY };
    });
    lZone.addEventListener('touchmove', e => {
        for (const t of e.changedTouches) {
            if (t.identifier === lId) {
                player.yaw -= (t.clientX - lastLook.x) * 0.005;
                player.pitch = Math.max(-1.2, Math.min(1.2, player.pitch - (t.clientY - lastLook.y) * 0.005));
                lastLook = { x: t.clientX, y: t.clientY };
            }
        }
    });
    lZone.addEventListener('touchend', () => lId = null);

    window.addEventListener('keydown', e => keys[e.code] = true);
    window.addEventListener('keyup', e => keys[e.code] = false);
}

initThree();
bindControls();
animate();
