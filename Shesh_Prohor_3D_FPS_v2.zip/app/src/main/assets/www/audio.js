class SoundEngine {
    constructor() {
        this.ctx = null;
        this.musicOn = true;
        this.musicTimer = null;
    }
    init() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            this.ctx = new AudioCtx();
        }
        if (this.ctx.state === 'suspended') this.ctx.resume();
        if (this.musicOn && !this.musicTimer) this.startEmotionalMusic();
    }
    toggleMusic() {
        this.musicOn = !this.musicOn;
        if (!this.musicOn && this.musicTimer) {
            clearInterval(this.musicTimer);
            this.musicTimer = null;
        } else if (this.musicOn) {
            this.init();
        }
        return this.musicOn;
    }
    startEmotionalMusic() {
        // Minor key emotional ambient chords (Am - F - C - G)
        const notes = [220.0, 261.63, 329.63, 174.61, 220.0, 261.63, 196.0, 246.94];
        let step = 0;
        this.musicTimer = setInterval(() => {
            if (!this.ctx || !this.musicOn) return;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(notes[step % notes.length], this.ctx.currentTime);
            gain.gain.setValueAtTime(0.001, this.ctx.currentTime);
            gain.gain.linearRampToValueAtTime(0.045, this.ctx.currentTime + 0.8);
            gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 2.8);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start();
            osc.stop(this.ctx.currentTime + 2.9);
            step++;
        }, 2400);
    }
    playNoise(duration, filterFreq, volume = 0.35, type = 'lowpass') {
        if (!this.ctx) return;
        const bufferSize = this.ctx.sampleRate * duration;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = this.ctx.createBiquadFilter();
        filter.type = type;
        filter.frequency.setValueAtTime(filterFreq, this.ctx.currentTime);
        filter.frequency.exponentialRampToValueAtTime(100, this.ctx.currentTime + duration);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(volume, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        noise.start();
    }
    playGunshot(weaponId) {
        this.init();
        if (weaponId === 'rifle') this.playNoise(0.14, 1400, 0.38);
        else if (weaponId === 'pistol') this.playNoise(0.09, 2200, 0.28);
        else if (weaponId === 'shotgun') this.playNoise(0.28, 900, 0.55);
        else if (weaponId === 'sniper') this.playNoise(0.32, 1800, 0.6);
    }
    playEnemyShot() {
        if (!this.ctx) return;
        this.playNoise(0.11, 1100, 0.16);
    }
    playExplosion() {
        this.init();
        this.playNoise(0.85, 380, 0.8);
    }
    playReload() {
        this.init();
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(520, this.ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(880, this.ctx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.15);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.16);
    }
    playHit() {
        this.init();
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1100, this.ctx.currentTime);
        gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.06);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.07);
    }
}
window.SFX = new SoundEngine();
