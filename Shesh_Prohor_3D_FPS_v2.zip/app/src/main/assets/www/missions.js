const ACTS = [
    { name: "অধ্যায় ১: অন্ধকারের সূচনা", mapType: "village", envCycle: ["day", "sunset", "day", "fog", "sunset"] },
    { name: "অধ্যায় ২: রক্তাক্ত শহর", mapType: "city", envCycle: ["day", "rain", "sunset", "night", "rain"] },
    { name: "অধ্যায় ৩: বৃষ্টিস্নাত অরণ্য", mapType: "forest", envCycle: ["rain", "fog", "night", "rain", "night"] },
    { name: "অধ্যায় ৪: ভাঙা সেতু ও প্রতিশোধ", mapType: "bridge", envCycle: ["sunset", "night", "fog", "rain", "sunset"] },
    { name: "অধ্যায় ৫: শেষ প্রহর", mapType: "fortress", envCycle: ["night", "rain", "sunset", "night", "day"] }
];

const KEY_EVENTS = {
    1: {
        title: "সীমান্তের প্রথম সকাল",
        intro: [
            { s: "মেজর আরিফ", t: "রাকিব, প্রস্তুত হও। শত্রুপক্ষ আমাদের সীমান্ত গ্রাম দখল করে নিয়েছে।" },
            { s: "তানভীর (সহযোদ্ধা)", t: "ভয় পাস না বন্ধু, আমি তোর পাশেই আছি। একসাথে ঢুকব, একসাথে ফিরব।" }
        ],
        mid: { s: "তানভীর", t: "বাম দিকের বাড়ির পেছনে শত্রু লুকিয়ে আছে! কভার নাও!" },
        outro: "প্রথম ঘাঁটি মুক্ত হয়েছে, কিন্তু যুদ্ধ কেবল শুরু।"
    },
    18: {
        title: "তানভীরের বিদায়",
        intro: [
            { s: "তানভীর", t: "রাকিব, আমি ডান দিকটা কভার দিচ্ছি। তুই সামনে এগিয়ে যা!" },
            { s: "রাকিব", t: "তানভীর, একা যাস না—ওখানে স্নাইপার আছে!" }
        ],
        mid: { s: "তানভীর (আহত)", t: "রাকিব... আমার... সময় শেষ... মাকে বলিস... আমি পালাইনি..." },
        outro: "তানভীর আর নেই। তার রাইফেলটা হাতে নিয়ে তুমি শপথ নিলে—এই রক্ত বৃথা যাবে না।"
    },
    38: {
        title: "মেজর আরিফের আত্মত্যাগ",
        intro: [
            { s: "মেজর আরিফ", t: "সেতুটা উড়িয়ে না দিলে ওদের ট্যাংক শহরে ঢুকে পড়বে। আমি ডেটোনেটর বসাচ্ছি!" },
            { s: "রাকিব", t: "স্যার, আপনি বেরোতে পারবেন না!" },
            { s: "মেজর আরিফ", t: "আমার চেয়ে দেশের মানুষের প্রাণ বড়, রাকিব। বিদায়, ছেলে..." }
        ],
        mid: { s: "মেজর আরিফ", t: "সবাইকে বাঁচাও রাকিব... শেষ প্রহর পর্যন্ত লড়ে যাও!" },
        outro: "সেতু ভেঙে পড়ল, সাথে হারিয়ে গেলেন তোমাদের পিতৃতুল্য কমান্ডার মেজর আরিফ।"
    },
    50: {
        title: "শেষ প্রহর (চূড়ান্ত যুদ্ধ)",
        intro: [
            { s: "রাকিব", t: "তানভীর, মেজর আরিফ—আজকের এই লড়াই তোমাদের জন্য।" },
            { s: "রফিক", t: "এটাই শেষ দুর্গ, রাকিব। চলো, এই অন্ধকারের অবসান ঘটাই!" }
        ],
        mid: { s: "শত্রু কমান্ডার", t: "তুমি একা আমাদের থামাতে পারবে না!" },
        outro: "সূর্য উঠছে। যুদ্ধ শেষ। হারানো বন্ধুদের স্মৃতি বুকে নিয়ে নতুন সকালের পথে হাঁটছ তুমি..."
    }
};

function generateMissions() {
    const list = [];
    for (let i = 1; i <= 50; i++) {
        const actIdx = Math.floor((i - 1) / 10);
        const act = ACTS[actIdx];
        const env = act.envCycle[(i - 1) % act.envCycle.length];
        const custom = KEY_EVENTS[i];

        const enemies = Math.min(26, 4 + Math.floor(i * 0.42));
        const enemyHp = 65 + i * 4;
        const enemySpeed = 2.0 + Math.min(2.4, i * 0.04);
        const allyName = i < 18 ? "তানভীর" : (i < 38 ? "মেজর আরিফ" : "রফিক");

        list.push({
            id: i,
            act: act.name,
            mapType: act.mapType,
            title: custom ? custom.title : `অভিযান ${i}: ${act.name.split(":")[1].trim()}`,
            env: env,
            enemies: enemies,
            enemyHp: enemyHp,
            enemySpeed: enemySpeed,
            allyName: allyName,
            objective: `সকল শত্রু নির্মূল করুন (${enemies} জন)`,
            intro: custom ? custom.intro : [
                { s: allyName, t: `মিশন ${i} শুরু হচ্ছে। আমি তোমার সাথেই লড়ছি—কভার নিয়ে এগোও!` },
                { s: "রাকিব", t: "ঠিক আছে, শত্রুদের একটাও যেন পালাতে না পারে!" }
            ],
            mid: custom ? custom.mid : { s: allyName, t: "অর্ধেক শত্রু শেষ! বাকিদের ওপর চাপ বাড়াও!" },
            outro: custom ? custom.outro : `মিশন ${i} সফলভাবে সম্পন্ন হয়েছে। চেকপয়েন্ট সংরক্ষিত।`
        });
    }
    return list;
}

window.MISSIONS = generateMissions();
